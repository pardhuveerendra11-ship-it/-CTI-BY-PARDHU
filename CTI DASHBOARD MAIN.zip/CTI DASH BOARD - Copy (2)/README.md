# -CTI-BY-PARDHU
ShadowNexus SOC OS v3.0 — Cyber Threat Intelligence & Incident Response Platform
Developed by Pardhu Veerendra
