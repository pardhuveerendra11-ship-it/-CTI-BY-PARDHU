from fastapi import APIRouter
from backend.api.endpoints import (
    dashboard,
    intel,
    intel_workspace,
    omega_intel,
    omega_prime,
    cti,
    monitoring,
    incidents,
    assets,
    vulnerabilities,
    analytics,
    threat_map,
    reports,
    settings
)

api_router = APIRouter()

api_router.include_router(cti.router, prefix="/cti", tags=["0. CTI Platform Backend Connector"])
api_router.include_router(omega_prime.router, prefix="/omega-prime", tags=["0. Omega Prime Master SOC Platform"])
api_router.include_router(dashboard.router, prefix="/dashboard", tags=["1. Dashboard"])
api_router.include_router(omega_intel.router, prefix="/omega/intel", tags=["2. Omega XDR Threat Intelligence Engine"])
api_router.include_router(intel_workspace.router, prefix="/intel/workspace", tags=["2. Threat Intelligence Workspace"])
api_router.include_router(intel.router, prefix="/intel", tags=["2. Threat Intelligence Core"])
api_router.include_router(intel.router, prefix="", tags=["2. Threat Intelligence Legacy"])
api_router.include_router(monitoring.router, prefix="/monitoring", tags=["3. Security Monitoring"])
api_router.include_router(incidents.router, prefix="/incidents", tags=["4. Incidents"])
api_router.include_router(assets.router, prefix="/assets", tags=["5. Assets"])
api_router.include_router(vulnerabilities.router, prefix="/vulnerabilities", tags=["6. Vulnerabilities"])
api_router.include_router(analytics.router, prefix="/analytics", tags=["7. Analytics"])
api_router.include_router(threat_map.router, prefix="/threat-map", tags=["8. Threat Map"])
api_router.include_router(reports.router, prefix="/reports", tags=["9. Reports"])
api_router.include_router(settings.router, prefix="/settings", tags=["10. Settings"])
