from fastapi import APIRouter

router = APIRouter()

@router.get("/trends")
async def get_analytics_trends():
    return {
        "mttd_minutes": 4.2,
        "mttr_minutes": 18.5,
        "attack_vectors": [
            {"vector": "Phishing Email", "percentage": 42},
            {"vector": "Exploit Public App", "percentage": 28},
            {"vector": "Valid Accounts", "percentage": 18},
            {"vector": "Supply Chain", "percentage": 12}
        ]
    }
