from fastapi import APIRouter, Body
from typing import Dict, Any

router = APIRouter()

@router.get("/summary")
async def get_omega_prime_summary():
    return {
        "platform": "ShadowNexus SOC OS v3.0",
        "security_score": 88,
        "threat_level": "ELEVATED",
        "active_playbooks": 4,
        "automated_responses_today": 12,
        "regional_risk": [
            {"region": "South Asia (India)", "risk_score": 91, "active_attacks": 14},
            {"region": "East Asia", "risk_score": 78, "active_attacks": 9},
            {"region": "Eastern Europe", "risk_score": 85, "active_attacks": 11},
        ]
    }

@router.get("/logs")
async def get_logs(query: str = "", limit: int = 50):
    sample_logs = [
        {"id": "LOG-001", "timestamp": "2026-07-29T22:00:00Z", "level": "CRITICAL", "source": "FIREWALL", "message": "Outbound connection blocked to 103.21.58.10:443 (LockBit C2)", "host": "DC01.threatnexus.local"},
        {"id": "LOG-002", "timestamp": "2026-07-29T22:01:00Z", "level": "HIGH", "source": "DNS_PROXY", "message": "DNS tunneling detected → malicious-exfil-node.net", "host": "DB-PRIMARY-01"},
        {"id": "LOG-003", "timestamp": "2026-07-29T22:02:00Z", "level": "CRITICAL", "source": "EDR", "message": "Ransomware binary hash matched: e3b0c44298fc1c149...", "host": "WSRV-FINANCE-01"},
        {"id": "LOG-004", "timestamp": "2026-07-29T22:03:00Z", "level": "HIGH", "source": "EMAIL_GW", "message": "Phishing email blocked — credential harvest payload detected", "host": "MAIL-SERVER-01"},
        {"id": "LOG-005", "timestamp": "2026-07-29T22:04:00Z", "level": "MEDIUM", "source": "SIEM", "message": "Lateral movement attempt via Pass-the-Hash", "host": "JUMP-SRV-01"},
    ]
    if query:
        filtered = [l for l in sample_logs if query.lower() in l["message"].lower() or query.lower() in l["source"].lower()]
        return {"logs": filtered[:limit], "total": len(filtered), "query": query}
    return {"logs": sample_logs[:limit], "total": len(sample_logs), "query": ""}

@router.post("/soar/execute")
async def execute_soar_playbook(payload: Dict[str, Any] = Body(default={})):
    playbook = payload.get("playbook", "ISOLATE_HOST")
    target = payload.get("target", "DC01.threatnexus.local")
    actions_map = {
        "ISOLATE_HOST": [
            f"✅ Quarantine NIC on {target} — VLAN-10 egress blocked",
            "✅ Memory snapshot captured via EDR agent",
            "✅ Alert dispatched to DFIR on-call team",
            "✅ Endpoint removed from Active Directory DNS"
        ],
        "LOCK_USER": [
            f"✅ AD account disabled for user on {target}",
            "✅ All OAuth 2.0 refresh tokens revoked",
            "✅ MFA reset enforced — re-enroll required",
            "✅ HR & CISO notified via automated ticket INC-2026-AUTO"
        ],
        "BLOCK_IP": [
            f"✅ ACL pushed to perimeter firewall — {target} null-routed",
            "✅ BGP blackhole route advertised to upstream ISP",
            "✅ Added to proxy blocklist across all 3 gateway clusters",
            "✅ IOC feed updated — shared to MISP & CTI platform"
        ],
        "KILL_PROCESS": [
            f"✅ SIGKILL sent via EDR agent on {target}",
            "✅ Process memory dumped → S3 forensics bucket",
            "✅ Malicious binary quarantined in EDR vault",
            "✅ SHA256 submitted to VirusTotal & MalwareBazaar sandbox"
        ],
    }
    timing_map = {
        "ISOLATE_HOST": 312,
        "LOCK_USER": 198,
        "BLOCK_IP": 445,
        "KILL_PROCESS": 267,
    }
    return {
        "status": "EXECUTED",
        "playbook": playbook,
        "target": target,
        "actions_completed": actions_map.get(playbook, [f"✅ Playbook '{playbook}' executed on {target}"]),
        "execution_time_ms": timing_map.get(playbook, 240),
        "analyst_notified": True
    }
