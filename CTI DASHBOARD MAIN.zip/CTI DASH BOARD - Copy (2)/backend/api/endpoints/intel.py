from typing import Dict, Any, Optional
from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from backend.database.database import get_db
from backend.database.models import IOC, ThreatActor, Malware, Campaign

router = APIRouter()

@router.get("/feeds")
async def get_intel_feeds():
    return [
        {"id": "feed-1", "title": "CISA KEV Vulnerability Feed", "status": "SYNCED", "indicator_count": "1,124 CVEs"},
        {"id": "feed-2", "title": "AbuseIPDB High Confidence IPs", "status": "SYNCED", "indicator_count": "4,890 IPs"},
        {"id": "feed-3", "title": "VirusTotal Threat Actor STIX Bundles", "status": "SYNCED", "indicator_count": "312 Bundles"},
        {"id": "feed-4", "title": "MalwareBazaar YARA Ruleset", "status": "SYNCED", "indicator_count": "850 Rules"}
    ]

@router.get("/iocs")
async def get_iocs(db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(IOC))
    iocs = res.scalars().all()
    return iocs

@router.get("/actors")
async def get_threat_actors(db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(ThreatActor))
    actors = res.scalars().all()
    return actors

@router.get("/stix/export")
async def export_stix_bundle(db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(IOC))
    iocs = res.scalars().all()
    stix_objects = []
    for i in iocs:
        pattern_type = "ipv4-addr" if i.type == "ip" else ("domain-name" if i.type == "domain" else "url")
        stix_objects.append({
            "type": "indicator",
            "spec_version": "2.1",
            "id": f"indicator--{i.id}",
            "name": f"{i.threat_type} Indicator",
            "pattern": f"[{pattern_type}:value = '{i.value}']",
            "pattern_type": "stix",
            "confidence": i.confidence
        })
    return {
        "type": "bundle",
        "id": "bundle--cti-shadownexus-export-001",
        "spec_version": "2.1",
        "objects": stix_objects
    }
