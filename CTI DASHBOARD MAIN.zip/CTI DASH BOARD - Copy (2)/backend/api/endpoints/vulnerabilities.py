import uuid
from typing import Optional, Any, Dict
from fastapi import APIRouter, Depends, HTTPException, Body, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import func, or_
from backend.database.database import get_db
from backend.database.models import Vulnerability

router = APIRouter()

# ── GET all vulnerabilities with optional search/filter ──────────────────────
@router.get("")
async def get_vulnerabilities(
    db: AsyncSession = Depends(get_db),
    search: Optional[str] = Query(None, description="Search CVE ID or description"),
    kev_only: Optional[bool] = Query(None, description="Filter CISA KEV only"),
    status: Optional[str] = Query(None, description="Filter by remediation_status"),
    min_cvss: Optional[float] = Query(None, description="Minimum CVSS score"),
    max_cvss: Optional[float] = Query(None, description="Maximum CVSS score"),
):
    q = select(Vulnerability)
    if search:
        q = q.where(or_(
            Vulnerability.cve_id.ilike(f"%{search}%"),
            Vulnerability.description.ilike(f"%{search}%"),
        ))
    if kev_only is True:
        q = q.where(Vulnerability.cisa_kev == True)
    if status:
        q = q.where(Vulnerability.remediation_status == status)
    if min_cvss is not None:
        q = q.where(Vulnerability.cvss_score >= min_cvss)
    if max_cvss is not None:
        q = q.where(Vulnerability.cvss_score <= max_cvss)

    res = await db.execute(q)
    vulns = res.scalars().all()
    return vulns


# ── GET summary KPIs ──────────────────────────────────────────────────────────
@router.get("/summary")
async def get_vuln_summary(db: AsyncSession = Depends(get_db)):
    total   = (await db.execute(select(func.count(Vulnerability.id)))).scalar() or 0
    kev     = (await db.execute(select(func.count(Vulnerability.id)).where(Vulnerability.cisa_kev == True))).scalar() or 0
    open_   = (await db.execute(select(func.count(Vulnerability.id)).where(Vulnerability.remediation_status == "OPEN"))).scalar() or 0
    patched = (await db.execute(select(func.count(Vulnerability.id)).where(Vulnerability.remediation_status == "PATCHED"))).scalar() or 0
    critical_kev = (await db.execute(select(func.count(Vulnerability.id)).where(
        Vulnerability.cisa_kev == True, Vulnerability.cvss_score >= 9.0
    ))).scalar() or 0
    avg_cvss = (await db.execute(select(func.avg(Vulnerability.cvss_score)))).scalar()

    return {
        "total": total,
        "cisa_kev": kev,
        "open": open_,
        "patched": patched,
        "critical_kev": critical_kev,
        "avg_cvss": round(float(avg_cvss), 1) if avg_cvss else 0.0,
    }


# ── GET single CVE ────────────────────────────────────────────────────────────
@router.get("/{cve_id}")
async def get_vulnerability(cve_id: str, db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(Vulnerability).where(Vulnerability.cve_id == cve_id))
    v = res.scalar_one_or_none()
    if not v:
        raise HTTPException(status_code=404, detail=f"CVE '{cve_id}' not found")
    return v


# ── POST create new CVE ───────────────────────────────────────────────────────
@router.post("")
async def create_vulnerability(payload: Dict[str, Any] = Body(...), db: AsyncSession = Depends(get_db)):
    cve_id = payload.get("cve_id", "").strip().upper()
    if not cve_id:
        raise HTTPException(status_code=422, detail="cve_id is required")

    existing = (await db.execute(select(Vulnerability).where(Vulnerability.cve_id == cve_id))).scalar_one_or_none()
    if existing:
        raise HTTPException(status_code=409, detail=f"{cve_id} already exists")

    new_vuln = Vulnerability(
        id=str(uuid.uuid4()),
        cve_id=cve_id,
        cvss_score=float(payload.get("cvss_score", 0.0)),
        cisa_kev=bool(payload.get("cisa_kev", False)),
        description=payload.get("description", ""),
        remediation_status=payload.get("remediation_status", "OPEN"),
    )
    db.add(new_vuln)
    await db.commit()
    await db.refresh(new_vuln)
    return new_vuln


# ── PATCH update remediation status ──────────────────────────────────────────
@router.patch("/{cve_id}/status")
async def update_remediation_status(
    cve_id: str,
    payload: Dict[str, Any] = Body(...),
    db: AsyncSession = Depends(get_db),
):
    res = await db.execute(select(Vulnerability).where(Vulnerability.cve_id == cve_id))
    v = res.scalar_one_or_none()
    if not v:
        raise HTTPException(status_code=404, detail=f"CVE '{cve_id}' not found")

    new_status = payload.get("remediation_status")
    if new_status not in ("OPEN", "IN_PROGRESS", "PATCHED", "ACCEPTED_RISK", "WONT_FIX"):
        raise HTTPException(status_code=422, detail="Invalid remediation_status value")

    v.remediation_status = new_status
    await db.commit()
    await db.refresh(v)
    return v


# ── DELETE CVE ────────────────────────────────────────────────────────────────
@router.delete("/{cve_id}")
async def delete_vulnerability(cve_id: str, db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(Vulnerability).where(Vulnerability.cve_id == cve_id))
    v = res.scalar_one_or_none()
    if not v:
        raise HTTPException(status_code=404, detail=f"CVE '{cve_id}' not found")
    await db.delete(v)
    await db.commit()
    return {"status": "DELETED", "cve_id": cve_id}
