from typing import Dict, Any, Optional
from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from backend.database.database import get_db
from backend.database.models import IOC
from backend.intelligence.cti_client import CTIClient, cti_client

router = APIRouter()

@router.get("/status")
async def get_cti_status():
    status = await cti_client.check_connection()
    return {
        "cti_platform": "OpenCTI Enterprise Platform",
        "repository_url": "https://github.com/OpenCTI-Platform/opencti.git",
        "graphql_endpoint": cti_client.graphql_url,
        "connection_details": status
    }

@router.post("/config")
async def configure_cti(payload: Dict[str, Any] = Body(...)):
    url = payload.get("url") or "http://localhost:8080"
    token = payload.get("token") or "cti-api-token-secret-key"

    global cti_client
    cti_client = CTIClient(url=url, token=token)
    status = await cti_client.check_connection()

    return {
        "status": "SUCCESS",
        "message": f"CTI GraphQL backend configured for {url}",
        "connection": status
    }

@router.get("/indicators")
async def get_cti_indicators(count: int = 25):
    indicators = await cti_client.fetch_indicators(count=count)
    return {
        "source": "OpenCTI Platform GraphQL API",
        "repository": "https://github.com/OpenCTI-Platform/opencti.git",
        "count": len(indicators),
        "indicators": indicators
    }

@router.post("/sync/pull")
async def pull_from_cti(db: AsyncSession = Depends(get_db)):
    indicators = await cti_client.fetch_indicators(count=50)
    imported_count = 0

    for ind in indicators:
        pattern = ind.get("pattern", "")
        val = pattern.split("=")[-1].strip(" '[]\"") if "=" in pattern else ind.get("name", "103.21.58.10")
        ioc_type = "ip" if "ipv4" in pattern.lower() else ("domain" if "domain" in pattern.lower() else "indicator")

        existing = (await db.execute(select(IOC).where(IOC.value == val))).scalar_one_or_none()
        if not existing:
            new_ioc = IOC(
                type=ioc_type,
                value=val,
                confidence=ind.get("confidence", 90),
                severity="critical" if ind.get("confidence", 90) > 85 else "high",
                threat_type=ind.get("name", "CTI STIX Import"),
                reputation_score=90,
                status="active"
            )
            db.add(new_ioc)
            imported_count += 1

    await db.commit()
    return {
        "status": "COMPLETED",
        "source": "OpenCTI Platform GraphQL Backend (https://github.com/OpenCTI-Platform/opencti.git)",
        "objects_fetched": len(indicators),
        "new_iocs_imported": imported_count
    }

@router.post("/sync/push")
async def push_to_cti(payload: Dict[str, Any] = Body(...)):
    stix_bundle = payload.get("stix_bundle") or {
        "type": "bundle",
        "id": "bundle--cti-export-001",
        "spec_version": "2.1",
        "objects": [
            {"type": "indicator", "id": "indicator--ioc-101", "name": "C2 Beacon", "pattern": "[ip-addr:value = '103.21.58.10']", "pattern_type": "stix"}
        ]
    }

    result = await cti_client.push_stix_bundle(stix_bundle)
    return {
        "status": "SUCCESS",
        "destination": "OpenCTI Platform GraphQL API",
        "repository": "https://github.com/OpenCTI-Platform/opencti.git",
        "result": result
    }
