from typing import Dict, Any, Optional
from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from backend.database.database import get_db
from backend.database.models import Alert

router = APIRouter()

SAMPLE_10_ALERTS = [
    {"id": "ALT-101", "title": "Port 443 Beaconing to LockBit C2 IP 103.21.58.10", "severity": "CRITICAL", "source": "FIREWALL_SYS", "ioc_value": "103.21.58.10", "mitre_tactic": "TA0011", "status": "NEW"},
    {"id": "ALT-102", "title": "DNS Tunneling Data Exfiltration to malicious-exfil-node.net", "severity": "HIGH", "source": "DNS_PROXY", "ioc_value": "malicious-exfil-node.net", "mitre_tactic": "TA0011", "status": "NEW"},
    {"id": "ALT-103", "title": "LockBit 3.0 Encryptor Executable Hash Match Detected", "severity": "CRITICAL", "source": "EDR_CROWDSTRIKE", "ioc_value": "e3b0c44298fc1c149afbf4c8...", "mitre_tactic": "TA0040", "status": "NEW"},
    {"id": "ALT-104", "title": "PowerShell Base64 Encoded Script Injection in Mail Process", "severity": "CRITICAL", "source": "WIN_EVT_LOG", "ioc_value": "powershell.exe -enc SQB...", "mitre_tactic": "TA0002", "status": "NEW"},
    {"id": "ALT-105", "title": "Spear-Phishing OAuth Credential Harvest Domain Query", "severity": "HIGH", "source": "EMAIL_GATEWAY", "ioc_value": "auth-verify-security-login.com", "mitre_tactic": "TA0001", "status": "ACK"},
    {"id": "ALT-106", "title": "Pass-the-Hash NTLM Relay Anomaly — JUMP-SRV to DB-PRIMARY", "severity": "CRITICAL", "source": "ACTIVE_DIRECTORY", "ioc_value": "Event ID 4624 Type 3", "mitre_tactic": "TA0003", "status": "NEW"},
    {"id": "ALT-107", "title": "Kerberoasting SPN Ticket Request Anomaly Flood", "severity": "HIGH", "source": "SIEM_SPLUNK", "ioc_value": "KRBTGT/threatnexus.local", "mitre_tactic": "TA0006", "status": "ACK"},
    {"id": "ALT-108", "title": "CVE-2026-1042 RCE Exploit Memory Corruption Payload", "severity": "CRITICAL", "source": "WAF_CLOUDFLARE", "ioc_value": "91.240.118.172", "mitre_tactic": "TA0001", "status": "NEW"},
    {"id": "ALT-109", "title": "Lazarus Group Crypto-Exfiltration API Endpoint Access", "severity": "CRITICAL", "source": "API_GATEWAY", "ioc_value": "5.188.86.172", "mitre_tactic": "TA0010", "status": "NEW"},
    {"id": "ALT-110", "title": "ShadowPad Trojan DLL Side-Loading Anomaly on Endpoint", "severity": "HIGH", "source": "EDR_DEFENDER", "ioc_value": "vendor-sdk-v2.3.1.dll", "mitre_tactic": "TA0005", "status": "CLOSED"},
]

@router.get("/alerts")
async def get_alerts(db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(Alert))
    alerts = res.scalars().all()
    if not alerts:
        return SAMPLE_10_ALERTS
    return alerts

@router.post("/alerts/generate-sample-10")
async def generate_sample_10_alerts(db: AsyncSession = Depends(get_db)):
    added_count = 0
    for item in SAMPLE_10_ALERTS:
        res = await db.execute(select(Alert).where(Alert.id == item["id"]))
        existing = res.scalar_one_or_none()
        if not existing:
            alt = Alert(
                id=item["id"],
                title=item["title"],
                severity=item["severity"],
                source=item["source"],
                ioc_value=item["ioc_value"],
                mitre_tactic=item["mitre_tactic"],
                status=item["status"]
            )
            db.add(alt)
            added_count += 1
    await db.commit()
    return {"status": "SUCCESS", "message": f"Added {added_count} sample alerts", "added_count": added_count}

@router.post("/alerts")
async def create_alert(payload: Dict[str, Any] = Body(...), db: AsyncSession = Depends(get_db)):
    new_alert = Alert(
        id=payload.get("id", f"ALT-{100 + len(SAMPLE_10_ALERTS)}"),
        title=payload.get("title", "Generic Alert"),
        severity=payload.get("severity", "HIGH"),
        source=payload.get("source", "SIEM"),
        ioc_value=payload.get("ioc_value", "127.0.0.1"),
        mitre_tactic=payload.get("mitre_tactic", "TA0001"),
        status=payload.get("status", "NEW")
    )
    db.add(new_alert)
    await db.commit()
    await db.refresh(new_alert)
    return new_alert

@router.patch("/alerts/{alert_id}")
async def update_alert(alert_id: str, payload: Dict[str, Any] = Body(default={}), db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(Alert).where(Alert.id == alert_id))
    alert = res.scalar_one_or_none()
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    if "status" in payload:
        alert.status = payload["status"]
    await db.commit()
    return alert
