from typing import Dict, Any, Optional
from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from backend.database.database import get_db
from backend.database.models import Incident

router = APIRouter()

SAMPLE_10_INCIDENTS = [
    {"id": "INC-2026-001", "title": "Active LockBit 3.0 Ransomware Beaconing — DC01", "severity": "CRITICAL", "status": "OPEN",
     "assigned_analyst": "Tier 3 SOC Lead", "summary": "C2 beaconing detected from DC01.threatnexus.local to 103.21.58.10:443. LockBit encryptor binary hash confirmed on endpoint. Immediate containment required."},
    {"id": "INC-2026-002", "title": "APT29 Spear-Phishing Campaign — MAIL-SRV-01", "severity": "CRITICAL", "status": "IN_PROGRESS",
     "assigned_analyst": "DFIR Analyst — Pardhu V.", "summary": "NOBELIUM spear-phishing payload detected via MAIL-SRV-01. Credential harvesting link embedded in OneDrive-spoofed email. 3 executives clicked."},
    {"id": "INC-2026-003", "title": "DNS Tunneling Data Exfiltration — DNS-PROXY-01", "severity": "HIGH", "status": "OPEN",
     "assigned_analyst": "Tier 2 Analyst", "summary": "DNS TXT record exfiltration detected over malicious-exfil-node.net. Approx. 247 bytes/query with 30s beacon cadence. Consistent with dnscat2 C2 tunneling."},
    {"id": "INC-2026-004", "title": "SSH Brute Force Intrusion — JUMP-SRV-01", "severity": "HIGH", "status": "CLOSED",
     "assigned_analyst": "Tier 1 SOC Analyst", "summary": "Botnet Cluster B4 (194.26.29.112, NL) attempted 12,450 SSH login attempts against JUMP-SRV-01. Account lockout triggered. IP null-routed at perimeter."},
    {"id": "INC-2026-005", "title": "CVE-2026-1042 RCE Exploit Attempt — WEB-CLUSTER-02", "severity": "CRITICAL", "status": "IN_PROGRESS",
     "assigned_analyst": "Vulnerability Response Team", "summary": "APT33 (91.240.118.172, IR) exploited CVE-2026-1042 memory corruption vulnerability in Apache HTTP Server on WEB-CLUSTER-02. Reverse shell established — patch deployment in progress."},
    {"id": "INC-2026-006", "title": "Cobalt Strike Beacon — WSRV-FINANCE-01", "severity": "CRITICAL", "status": "OPEN",
     "assigned_analyst": "Tier 3 SOC Lead", "summary": "Cobalt Strike malleable C2 profile detected on WSRV-FINANCE-01. Beacon interval: 60s to update-service-cdn-cloud.net. Memory injection into svchost.exe confirmed via EDR."},
    {"id": "INC-2026-007", "title": "Lateral Movement via Pass-the-Hash — DB-PRIMARY-01", "severity": "HIGH", "status": "OPEN",
     "assigned_analyst": "DFIR Analyst — Pardhu V.", "summary": "Pass-the-Hash lateral movement detected from JUMP-SRV-01 to DB-PRIMARY-01 using stolen NTLM hash. Windows Event ID 4624 (Type 3 logon) anomaly confirmed."},
    {"id": "INC-2026-008", "title": "Qakbot Botnet Infection — WSRV-FINANCE-02", "severity": "HIGH", "status": "OPEN",
     "assigned_analyst": "Tier 2 Analyst", "summary": "Qakbot loader (a1b2c3d4e5f6...) detected on WSRV-FINANCE-02. C2 communication to darknet-c2-panel.xyz established. BOT registration gate POST confirmed at /gate.php."},
    {"id": "INC-2026-009", "title": "Lazarus Group Crypto Exfiltration — TRADE-SRV-01", "severity": "CRITICAL", "status": "IN_PROGRESS",
     "assigned_analyst": "Tier 3 SOC Lead", "summary": "Lazarus Group (5.188.86.172) targeting TRADE-SRV-01 cryptocurrency trading APIs. USD 2.3M equivalent in BTC exfiltrated via automated API drain. Incident escalated to CISO."},
    {"id": "INC-2026-010", "title": "Supply Chain Attack — vendor-sdk-package.dll", "severity": "HIGH", "status": "OPEN",
     "assigned_analyst": "Supply Chain Security Team", "summary": "ShadowPad RAT embedded in a third-party vendor SDK update (vendor-sdk-v2.3.1.dll). Hash f0e9d8c7... confirmed malicious. 6 endpoints auto-updated. Vendor notified and SDK revoked."},
]

@router.get("")
async def get_incidents(db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(Incident))
    incidents = res.scalars().all()
    if not incidents:
        return SAMPLE_10_INCIDENTS
    return incidents

@router.post("/generate-sample-10")
async def generate_sample_10_incidents(db: AsyncSession = Depends(get_db)):
    added_count = 0
    for item in SAMPLE_10_INCIDENTS:
        res = await db.execute(select(Incident).where(Incident.id == item["id"]))
        existing = res.scalar_one_or_none()
        if not existing:
            inc = Incident(
                id=item["id"],
                title=item["title"],
                severity=item["severity"],
                status=item["status"],
                assigned_analyst=item["assigned_analyst"],
                summary=item["summary"]
            )
            db.add(inc)
            added_count += 1
    await db.commit()
    return {"status": "SUCCESS", "message": f"Added {added_count} sample incidents", "added_count": added_count}

@router.patch("/{incident_id}")
async def update_incident(incident_id: str, payload: Dict[str, Any] = Body(default={}), db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(Incident).where(Incident.id == incident_id))
    incident = res.scalar_one_or_none()
    if not incident:
        raise HTTPException(status_code=404, detail="Incident not found")
    if "status" in payload:
        incident.status = payload["status"]
    await db.commit()
    return incident
