from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from backend.database.database import get_db
from backend.database.models import ThreatEvent

router = APIRouter()

@router.get("/events")
async def get_threat_map_events(db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(ThreatEvent))
    events = res.scalars().all()
    return events
