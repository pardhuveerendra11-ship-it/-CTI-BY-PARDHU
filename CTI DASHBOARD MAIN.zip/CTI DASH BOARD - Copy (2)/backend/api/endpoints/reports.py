from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import func, or_
from backend.database.database import get_db
from backend.database.models import (
    ThreatReport, ReportVersion, ReportTag, ReportAttachment,
    ReportIOC, ReportTimelineEvent, ReportMitigation,
    ReportAuditLog, ReportDownload, Report
)
from datetime import datetime, timedelta
import uuid, json, csv, io

router = APIRouter()

# ── helpers ──────────────────────────────────────────────────────────────────

def _uid():
    return str(uuid.uuid4())

def _rpt_id():
    return f"RPT-{datetime.utcnow().year}-{str(uuid.uuid4())[:6].upper()}"

def _row(r):
    """Serialize a ThreatReport SQLAlchemy row to dict."""
    return {
        "id": r.id,
        "report_id_display": r.report_id_display,
        "title": r.title,
        "category": r.category,
        "severity": r.severity,
        "status": r.status,
        "threat_type": r.threat_type,
        "affected_assets": r.affected_assets or [],
        "assigned_analyst": r.assigned_analyst,
        "classification": r.classification,
        "risk_score": r.risk_score,
        "confidence_level": r.confidence_level,
        "version": r.version,
        "executive_summary": r.executive_summary,
        "business_impact": r.business_impact,
        "threat_overview": r.threat_overview,
        "overall_recommendation": r.overall_recommendation,
        "created_at": r.created_at.isoformat() if r.created_at else None,
        "updated_at": r.updated_at.isoformat() if r.updated_at else None,
        "review_date": r.review_date.isoformat() if r.review_date else None,
        "closed_at": r.closed_at.isoformat() if r.closed_at else None,
    }

# ── rich mock data (fallback when DB is empty) ────────────────────────────────

MOCK_REPORTS = [
    {"id":"m1","report_id_display":"RPT-2026-A1F3","title":"APT29 Cozy Bear — Spear Phishing Campaign Analysis","category":"Threat Actor","severity":"CRITICAL","status":"OPEN","threat_type":"APT","affected_assets":["DC01","MAIL-SRV-01","AD-PRIMARY"],"assigned_analyst":"S. Veerendra","classification":"TLP:RED","risk_score":94,"confidence_level":97,"version":3,"executive_summary":"APT29 targeted government contractors via spear phishing delivering NOBELIUM malware payload.","business_impact":"Potential exfiltration of classified contracts and PII. Estimated impact: $2.4M.","threat_overview":"Observed use of HTML smuggling and MSHTML CVE-2021-40444 to deliver custom dropper.","overall_recommendation":"Isolate affected endpoints, rotate credentials, deploy YARA rule NOBL-2026-07.","created_at":"2026-07-28T08:00:00","updated_at":"2026-07-29T18:30:00","review_date":"2026-08-05T09:00:00","closed_at":None},
    {"id":"m2","report_id_display":"RPT-2026-B2E7","title":"LockBit 3.0 Ransomware Deployment — Finance Sector","category":"Incident","severity":"CRITICAL","status":"INVESTIGATING","threat_type":"Ransomware","affected_assets":["WSRV-FINANCE-01","DB-PRIMARY-01","BACKUP-SRV"],"assigned_analyst":"R. Analyst","classification":"TLP:AMBER","risk_score":91,"confidence_level":99,"version":2,"executive_summary":"LockBit 3.0 ransomware deployed via compromised RDP session targeting financial systems.","business_impact":"42 endpoints encrypted. Finance operations halted for 18 hours. Recovery cost ~$890K.","threat_overview":"Initial access via brute-forced RDP on WSRV-FINANCE-01. Lateral movement using PsExec.","overall_recommendation":"Block all external RDP. Restore from clean backup. Engage IR team immediately.","created_at":"2026-07-29T22:00:00","updated_at":"2026-07-30T01:15:00","review_date":"2026-08-01T10:00:00","closed_at":None},
    {"id":"m3","report_id_display":"RPT-2026-C3D9","title":"DNS Exfiltration via Covert Channel — Q3 2026","category":"Exfiltration","severity":"HIGH","status":"CONTAINED","threat_type":"Data Exfiltration","affected_assets":["DNS-PROXY-01","CORP-WS-0042"],"assigned_analyst":"K. Mehta","classification":"TLP:AMBER","risk_score":78,"confidence_level":88,"version":1,"executive_summary":"Covert DNS channel used to exfiltrate ~480MB of internal documents over 14 days.","business_impact":"Internal project documents exposed. Regulatory notification may be required.","threat_overview":"Base64-encoded data embedded in DNS TXT queries to attacker-controlled domain.","overall_recommendation":"Deploy DNS sinkholing for malicious-exfil-node.net. Audit all DNS traffic logs.","created_at":"2026-07-20T14:00:00","updated_at":"2026-07-27T09:00:00","review_date":"2026-08-10T00:00:00","closed_at":None},
    {"id":"m4","report_id_display":"RPT-2026-D4C2","title":"Cobalt Strike Beacon Infrastructure Mapping","category":"Threat Intelligence","severity":"HIGH","status":"CLOSED","threat_type":"C2 Framework","affected_assets":["JUMP-SRV-01","HR-WORKSTATION-07"],"assigned_analyst":"S. Veerendra","classification":"TLP:WHITE","risk_score":72,"confidence_level":93,"version":4,"executive_summary":"Mapped active Cobalt Strike team server infrastructure used in targeted attack.","business_impact":"Lateral movement prevented after early detection. No data exfiltration confirmed.","threat_overview":"Beacon communicated over HTTPS to 45.33.32.156 using malleable C2 profile.","overall_recommendation":"Block C2 IPs at perimeter. Deploy memory scan for Cobalt Strike artifacts.","created_at":"2026-07-15T11:00:00","updated_at":"2026-07-25T16:00:00","review_date":None,"closed_at":"2026-07-26T10:00:00"},
    {"id":"m5","report_id_display":"RPT-2026-E5B1","title":"Credential Phishing Portal — Executive Targeting","category":"Phishing","severity":"MEDIUM","status":"CLOSED","threat_type":"Phishing","affected_assets":["AD-USER-PARDH","AD-USER-CEO"],"assigned_analyst":"T. Singh","classification":"TLP:GREEN","risk_score":55,"confidence_level":82,"version":1,"executive_summary":"Phishing campaign targeting C-suite accounts via spoofed Microsoft 365 login portal.","business_impact":"2 executive accounts temporarily compromised. MFA prevented token theft.","threat_overview":"HTML page hosted at auth-credential-harvest.ru mimicking Microsoft 365 login.","overall_recommendation":"Reset affected account passwords. Enable phishing-resistant FIDO2 MFA.","created_at":"2026-07-10T09:00:00","updated_at":"2026-07-12T14:00:00","review_date":None,"closed_at":"2026-07-13T08:00:00"},
    {"id":"m6","report_id_display":"RPT-2026-F6A8","title":"India Threat Landscape — Q3 2026 Executive Brief","category":"Executive Summary","severity":"MEDIUM","status":"REVIEW","threat_type":"Regional Intelligence","affected_assets":[],"assigned_analyst":"S. Veerendra","classification":"TLP:WHITE","risk_score":60,"confidence_level":78,"version":2,"executive_summary":"Quarterly threat landscape covering active APT groups targeting Indian organizations.","business_impact":"Sector-wide risk elevation. Critical infrastructure and fintech most targeted.","threat_overview":"Increased activity from Sidewinder, Lazarus Group, and domestic hacktivist collectives.","overall_recommendation":"Elevate security posture for OT/ICS networks. Review supply chain security.","created_at":"2026-07-25T10:00:00","updated_at":"2026-07-29T12:00:00","review_date":"2026-08-02T09:00:00","closed_at":None},
    {"id":"m7","report_id_display":"RPT-2026-G7B9","title":"Zero-Day RCE Exploit in Spring Framework (CVE-2026-1042)","category":"Incident","severity":"CRITICAL","status":"OPEN","threat_type":"Vulnerability Exploitation","affected_assets":["WEB-CLUSTER-01","WEB-CLUSTER-02","API-GW-01"],"assigned_analyst":"S. Veerendra","classification":"TLP:RED","risk_score":98,"confidence_level":96,"version":2,"executive_summary":"Zero-day unauthenticated remote code execution vulnerability exploited in production web clusters.","business_impact":"Full web cluster compromise risk. Emergency maintenance window scheduled. Estimated impact: $1.8M.","threat_overview":"Attacker sent crafted HTTP POST request containing malicious serialized payload to execute arbitrary shellcode.","overall_recommendation":"Apply vendor emergency patch immediately; deploy WAF rules blocking payload patterns.","created_at":"2026-07-29T14:00:00","updated_at":"2026-07-30T02:00:00","review_date":"2026-08-03T10:00:00","closed_at":None},
    {"id":"m8","report_id_display":"RPT-2026-H8C4","title":"Supply Chain Trojanization Analysis — Vendor Plugin Incident","category":"Threat Intelligence","severity":"CRITICAL","status":"INVESTIGATING","threat_type":"Supply Chain","affected_assets":["BUILD-NODE-03","CI-CD-SERVER"],"assigned_analyst":"R. Analyst","classification":"TLP:AMBER","risk_score":93,"confidence_level":91,"version":1,"executive_summary":"Third-party build plugin compromised at source repository to inject backdoor DLL during software build cycles.","business_impact":"Software build pipeline compromised; downstream customers notified. Legal and compliance review initiated.","threat_overview":"Trojanized DLL contained obfuscated C2 beaconing routine connecting to external adversary server.","overall_recommendation":"Revoke compromised plugin credentials, rebuild build nodes from known good images, enforce code signing.","created_at":"2026-07-27T11:00:00","updated_at":"2026-07-29T19:00:00","review_date":"2026-08-04T09:00:00","closed_at":None},
    {"id":"m9","report_id_display":"RPT-2026-I9D1","title":"Active Directory Kerberoasting & DCSync Attack Investigation","category":"Incident","severity":"HIGH","status":"CONTAINED","threat_type":"Privilege Escalation","affected_assets":["DC01.threatnexus.local","AD-PRIMARY"],"assigned_analyst":"S. Veerendra","classification":"TLP:AMBER","risk_score":85,"confidence_level":94,"version":2,"executive_summary":"Attacker executed Kerberoasting to request SPN tickets, followed by DCSync attempt against Active Directory.","business_impact":"Domain admin hash exposed; password reset required across all privileged domain service accounts.","threat_overview":"Extracted Service Principal Names (SPN) offline cracked; rogue DCSync replication initiated from workstation.","overall_recommendation":"Reset krbtgt account password twice, enforce AES256-only Kerberos encryption, audit SPN accounts.","created_at":"2026-07-24T16:00:00","updated_at":"2026-07-28T10:00:00","review_date":"2026-08-08T00:00:00","closed_at":None},
    {"id":"m10","report_id_display":"RPT-2026-J0E5","title":"Cloud Infrastructure S3 Data Exfiltration Alert","category":"Exfiltration","severity":"HIGH","status":"CLOSED","threat_type":"Cloud Security","affected_assets":["AWS-S3-FINANCIAL-DATA","CLOUD-GATEWAY"],"assigned_analyst":"K. Mehta","classification":"TLP:GREEN","risk_score":76,"confidence_level":89,"version":1,"executive_summary":"Unauthorized API calls detected retrieving 120GB of archived customer data from misconfigured cloud bucket.","business_impact":"Customer PII exposed. Data Protection Officer notified for GDPR/CERT-In filing.","threat_overview":"Leaked IAM access key utilized from non-corporate IP address to execute bulk S3 GetObject calls.","overall_recommendation":"Revoke leaked IAM keys, enable S3 Block Public Access globally, enforce SCP policies.","created_at":"2026-07-18T13:00:00","updated_at":"2026-07-22T15:00:00","review_date":None,"closed_at":"2026-07-23T11:00:00"},
    {"id":"m11","report_id_display":"RPT-2026-K1F8","title":"NTP Monlist Reflection Volumetric DDoS Attack Campaign","category":"Incident","severity":"HIGH","status":"CLOSED","threat_type":"DDoS Attack","affected_assets":["EDGE-ROUTER-01","FIREWALL-CLUSTER-01"],"assigned_analyst":"T. Singh","classification":"TLP:WHITE","risk_score":70,"confidence_level":99,"version":1,"executive_summary":"14.2 Gbps NTP reflection DDoS attack targeted edge perimeter firewalls for 45 minutes.","business_impact":"Temporary latency elevation for external customer portal. ISP scrubbing redirected traffic successfully.","threat_overview":"UDP monlist reflection amplification factor ~556x deployed by botnet cluster B4.","overall_recommendation":"Maintain active BGP anycast scrubbing rules; disable monlist on internal NTP servers.","created_at":"2026-07-12T18:00:00","updated_at":"2026-07-13T10:00:00","review_date":None,"closed_at":"2026-07-14T08:00:00"},
    {"id":"m12","report_id_display":"RPT-2026-L2G3","title":"OT/ICS SCADA Malware Targeting Power Grid Controllers","category":"Executive Summary","severity":"CRITICAL","status":"REVIEW","threat_type":"Critical Infrastructure","affected_assets":["SCADA-GATEWAY-01","PLC-CONTROLLER-04"],"assigned_analyst":"S. Veerendra","classification":"TLP:RED","risk_score":97,"confidence_level":92,"version":3,"executive_summary":"Custom ICS malware designed to manipulate Modbus PLC commands identified in air-gapped network segment.","business_impact":"High physical safety and grid operational continuity risk. Critical infrastructure authorities notified.","threat_overview":"Malware injected via USB drive onto SCADA engineering station; altered PLC coil values.","overall_recommendation":"Enforce strict USB port physical lockouts; deploy industrial protocol anomaly detection sensors.","created_at":"2026-07-26T07:00:00","updated_at":"2026-07-29T20:00:00","review_date":"2026-08-06T09:00:00","closed_at":None},
]

MOCK_IOCS = {
    "m1": [
        {"id":"i1","ioc_type":"IP","value":"185.220.101.45","confidence":96,"status":"ACTIVE","first_seen":"2026-07-28T08:00:00","last_seen":"2026-07-29T18:00:00"},
        {"id":"i2","ioc_type":"DOMAIN","value":"nobelium-c2-infra.net","confidence":98,"status":"ACTIVE","first_seen":"2026-07-27T00:00:00","last_seen":"2026-07-29T22:00:00"},
        {"id":"i3","ioc_type":"HASH","value":"e3b0c44298fc1c149afbf4c8996fb924","confidence":99,"status":"ACTIVE","first_seen":"2026-07-28T10:00:00","last_seen":"2026-07-28T10:00:00"},
        {"id":"i4","ioc_type":"URL","value":"https://nobelium-c2-infra.net/stage2.dll","confidence":95,"status":"ACTIVE","first_seen":"2026-07-28T09:30:00","last_seen":"2026-07-29T17:00:00"},
    ],
    "m2": [
        {"id":"i5","ioc_type":"IP","value":"103.21.58.10","confidence":99,"status":"ACTIVE","first_seen":"2026-07-29T22:00:00","last_seen":"2026-07-30T01:00:00"},
        {"id":"i6","ioc_type":"HASH","value":"a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3","confidence":99,"status":"ACTIVE","first_seen":"2026-07-29T22:10:00","last_seen":"2026-07-30T00:00:00"},
        {"id":"i7","ioc_type":"URL","value":"http://103.21.58.10/payload/lockbit.exe","confidence":97,"status":"ACTIVE","first_seen":"2026-07-29T22:05:00","last_seen":"2026-07-30T01:15:00"},
    ],
    "m3": [
        {"id":"i8","ioc_type":"DOMAIN","value":"malicious-exfil-node.net","confidence":92,"status":"CONTAINED","first_seen":"2026-07-20T14:00:00","last_seen":"2026-07-27T09:00:00"},
        {"id":"i9","ioc_type":"IP","value":"45.33.32.156","confidence":88,"status":"CONTAINED","first_seen":"2026-07-21T10:00:00","last_seen":"2026-07-27T08:30:00"},
    ],
    "m4": [
        {"id":"i10","ioc_type":"IP","value":"194.26.29.112","confidence":95,"status":"BLOCKED","first_seen":"2026-07-15T11:00:00","last_seen":"2026-07-25T16:00:00"},
        {"id":"i11","ioc_type":"HASH","value":"9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08","confidence":94,"status":"BLOCKED","first_seen":"2026-07-15T12:00:00","last_seen":"2026-07-25T16:00:00"},
    ],
    "m5": [
        {"id":"i12","ioc_type":"URL","value":"http://auth-credential-harvest.ru/login.php","confidence":91,"status":"BLOCKED","first_seen":"2026-07-10T09:00:00","last_seen":"2026-07-12T14:00:00"},
        {"id":"i13","ioc_type":"EMAIL","value":"admin-security-alert@auth-credential-harvest.ru","confidence":89,"status":"BLOCKED","first_seen":"2026-07-10T09:05:00","last_seen":"2026-07-12T14:00:00"},
    ],
    "m6": [
        {"id":"i14","ioc_type":"IP","value":"91.240.118.172","confidence":85,"status":"MONITORED","first_seen":"2026-07-25T10:00:00","last_seen":"2026-07-29T12:00:00"},
        {"id":"i15","ioc_type":"DOMAIN","value":"apt-sidewinder-recon.org","confidence":87,"status":"MONITORED","first_seen":"2026-07-25T11:00:00","last_seen":"2026-07-29T12:00:00"},
    ],
}

MOCK_TIMELINE = {
    "m1": [
        {"phase":"Detection","event_ts":"2026-07-28T08:14:00","analyst":"SIEM Auto","description":"Abnormal outbound DNS queries detected by Zeek IDS signature.","status":"COMPLETED"},
        {"phase":"Analysis","event_ts":"2026-07-28T08:45:00","analyst":"S. Veerendra","description":"Confirmed APT29 TTPs: HTML smuggling + NOBELIUM dropper payload identified.","status":"COMPLETED"},
        {"phase":"Escalation","event_ts":"2026-07-28T09:00:00","analyst":"S. Veerendra","description":"Escalated to CISO and IR lead. P1 incident declared.","status":"COMPLETED"},
        {"phase":"Investigation","event_ts":"2026-07-28T10:30:00","analyst":"IR Team","description":"Full forensic triage of DC01 and MAIL-SRV-01. Memory dumps acquired.","status":"COMPLETED"},
        {"phase":"Containment","event_ts":"2026-07-28T13:00:00","analyst":"SOC Team","description":"Affected hosts isolated. C2 IPs blocked at perimeter firewall.","status":"COMPLETED"},
        {"phase":"Recovery","event_ts":"2026-07-29T08:00:00","analyst":"IT Ops","description":"Clean images deployed to affected endpoints. Credentials rotated.","status":"IN_PROGRESS"},
        {"phase":"Closure","event_ts":None,"analyst":"S. Veerendra","description":"Awaiting sign-off from CISO after 72-hour clean monitoring period.","status":"PENDING"},
    ],
    "m2": [
        {"phase":"Detection","event_ts":"2026-07-29T22:00:00","analyst":"EDR Alert","description":"LockBit 3.0 ransomware shadow copy deletion activity detected on WSRV-FINANCE-01.","status":"COMPLETED"},
        {"phase":"Analysis","event_ts":"2026-07-29T22:30:00","analyst":"R. Analyst","description":"Confirmed binary hash match for LockBit 3.0 strain. RDP compromise source identified.","status":"COMPLETED"},
        {"phase":"Containment","event_ts":"2026-07-30T00:15:00","analyst":"SOC Team","description":"Network segment isolated; external RDP ports disabled.","status":"COMPLETED"},
    ],
    "m3": [
        {"phase":"Detection","event_ts":"2026-07-20T14:00:00","analyst":"DNS Sentinel","description":"High volume TXT record queries to malicious-exfil-node.net detected.","status":"COMPLETED"},
        {"phase":"Containment","event_ts":"2026-07-21T09:00:00","analyst":"K. Mehta","description":"DNS sinkholing rule deployed across internal resolvers.","status":"COMPLETED"},
    ],
    "m4": [
        {"phase":"Detection","event_ts":"2026-07-15T11:00:00","analyst":"SIEM Auto","description":"Cobalt Strike HTTPS Malleable C2 beacon heartbeat matched.","status":"COMPLETED"},
        {"phase":"Closure","event_ts":"2026-07-26T10:00:00","analyst":"S. Veerendra","description":"C2 infrastructure sinkholed and endpoints verified clean.","status":"COMPLETED"},
    ],
    "m5": [
        {"phase":"Detection","event_ts":"2026-07-10T09:00:00","analyst":"Email Security","description":"Phishing alert: M365 credential harvester detected.","status":"COMPLETED"},
        {"phase":"Closure","event_ts":"2026-07-13T08:00:00","analyst":"T. Singh","description":"Executive accounts secured with FIDO2 tokens. Domain takedown submitted.","status":"COMPLETED"},
    ],
    "m6": [
        {"phase":"Analysis","event_ts":"2026-07-25T10:00:00","analyst":"S. Veerendra","description":"Aggregated regional threat intelligence for Q3 2026 executive briefing.","status":"COMPLETED"},
    ],
}

MOCK_MITIGATIONS = {
    "m1": [
        {"id":"mg1","action":"Block APT29 C2 IPs at perimeter firewall (185.220.101.45, 45.33.32.156)","priority":"CRITICAL","status":"COMPLETED","verified_by":"Network Team","estimated_completion":"2026-07-28T14:00:00"},
        {"id":"mg2","action":"Deploy YARA rule NOBL-2026-07 across all EDR agents","priority":"CRITICAL","status":"COMPLETED","verified_by":"SOC Analyst","estimated_completion":"2026-07-28T16:00:00"},
        {"id":"mg3","action":"Rotate all AD service account credentials","priority":"HIGH","status":"IN_PROGRESS","verified_by":None,"estimated_completion":"2026-07-30T12:00:00"},
        {"id":"mg4","action":"Enable MFA on all privileged accounts","priority":"HIGH","status":"PENDING","verified_by":None,"estimated_completion":"2026-08-02T00:00:00"},
        {"id":"mg5","action":"Submit threat intel report to CERT-In","priority":"MEDIUM","status":"PENDING","verified_by":None,"estimated_completion":"2026-08-05T00:00:00"},
    ],
    "m2": [
        {"id":"mg6","action":"Isolate WSRV-FINANCE-01 and DB-PRIMARY-01 from network","priority":"CRITICAL","status":"COMPLETED","verified_by":"IR Team","estimated_completion":"2026-07-30T00:30:00"},
        {"id":"mg7","action":"Restore encrypted database volumes from immutable offline backup","priority":"CRITICAL","status":"IN_PROGRESS","verified_by":None,"estimated_completion":"2026-07-30T18:00:00"},
    ],
    "m3": [
        {"id":"mg8","action":"Enforce DNS Sinkholing for malicious-exfil-node.net","priority":"HIGH","status":"COMPLETED","verified_by":"NetOps","estimated_completion":"2026-07-21T10:00:00"},
    ],
    "m4": [
        {"id":"mg9","action":"Block C2 IP 194.26.29.112 at border gateway","priority":"HIGH","status":"COMPLETED","verified_by":"SecOps","estimated_completion":"2026-07-15T14:00:00"},
    ],
    "m5": [
        {"id":"mg10","action":"Enforce FIDO2 hardware token MFA for executive roster","priority":"MEDIUM","status":"COMPLETED","verified_by":"IAM Lead","estimated_completion":"2026-07-12T16:00:00"},
    ],
    "m6": [
        {"id":"mg11","action":"Review OT/ICS network perimeter defenses across regional sites","priority":"MEDIUM","status":"IN_PROGRESS","verified_by":None,"estimated_completion":"2026-08-10T00:00:00"},
    ],
}


MOCK_ATTACKS_DATA = [
    {"id":"ATK-001","indicator":"103.21.58.10","type":"IP","threat_type":"LockBit 3.0 C2 Beacon","severity":"CRITICAL","confidence":95,"siem_alert":"ALT-101","target_asset":"DC01.threatnexus.local","mitre_tactic":"TA0011 - C&C","source":"Firewall","timestamp":"2026-07-29T22:00:00Z"},
    {"id":"ATK-002","indicator":"malicious-exfil-node.net","type":"DOMAIN","threat_type":"DNS Exfiltration Channel","severity":"HIGH","confidence":90,"siem_alert":"ALT-102","target_asset":"DB-PRIMARY-01","mitre_tactic":"TA0010 - Exfiltration","source":"DNS Proxy","timestamp":"2026-07-29T22:05:00Z"},
    {"id":"ATK-003","indicator":"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855","type":"SHA256","threat_type":"LockBit 3.0 Ransomware Binary","severity":"CRITICAL","confidence":99,"siem_alert":"ALT-103","target_asset":"WSRV-FINANCE-01","mitre_tactic":"TA0040 - Impact","source":"EDR","timestamp":"2026-07-29T22:10:00Z"},
    {"id":"ATK-004","indicator":"http://auth-credential-harvest.ru/login.php","type":"URL","threat_type":"Credential Phishing Portal","severity":"HIGH","confidence":88,"siem_alert":"ALT-104","target_asset":"AD-USER-PARDH","mitre_tactic":"TA0006 - Credential Access","source":"Email Gateway","timestamp":"2026-07-29T22:15:00Z"},
    {"id":"ATK-005","indicator":"45.33.32.156","type":"IP","threat_type":"Cobalt Strike Beacon","severity":"CRITICAL","confidence":97,"siem_alert":"ALT-105","target_asset":"JUMP-SRV-01","mitre_tactic":"TA0011 - C&C","source":"IDS/IPS","timestamp":"2026-07-29T22:20:00Z"},
]

# ── Analytics KPI helper ──────────────────────────────────────────────────────

def _compute_kpis(reports):
    total = len(reports)
    open_r  = sum(1 for r in reports if r.get("status") == "OPEN")
    closed  = sum(1 for r in reports if r.get("status") == "CLOSED")
    critical= sum(1 for r in reports if r.get("severity") == "CRITICAL")
    high    = sum(1 for r in reports if r.get("severity") == "HIGH")
    today_s = datetime.utcnow().date().isoformat()
    today   = sum(1 for r in reports if (r.get("created_at") or "")[:10] == today_s)
    month_s = datetime.utcnow().strftime("%Y-%m")
    month   = sum(1 for r in reports if (r.get("created_at") or "")[:7] == month_s)
    assets  = sum(len(r.get("affected_assets") or []) for r in reports)
    invest  = sum(1 for r in reports if r.get("status") == "INVESTIGATING")
    avg_res = 4.2
    return {
        "total": total, "open": open_r, "closed": closed,
        "critical": critical, "high": high,
        "today": today, "month": month,
        "avg_resolution_days": avg_res,
        "assets_impacted": assets,
        "active_investigations": invest,
    }

# ══════════════════════════════════════════════════════════════════════════════
#  REPORT ENDPOINTS
# ══════════════════════════════════════════════════════════════════════════════

@router.get("")
async def list_reports(
    db: AsyncSession = Depends(get_db),
    q: str = Query("", description="Search query"),
    severity: str = Query("", description="Severity filter"),
    status: str = Query("", description="Status filter"),
    category: str = Query("", description="Category filter"),
    analyst: str = Query("", description="Analyst filter"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
):
    try:
        stmt = select(ThreatReport).where(ThreatReport.deleted_at == None)
        if q:
            stmt = stmt.where(or_(
                ThreatReport.title.ilike(f"%{q}%"),
                ThreatReport.report_id_display.ilike(f"%{q}%"),
                ThreatReport.assigned_analyst.ilike(f"%{q}%"),
            ))
        if severity: stmt = stmt.where(ThreatReport.severity == severity.upper())
        if status:   stmt = stmt.where(ThreatReport.status == status.upper())
        if category: stmt = stmt.where(ThreatReport.category == category)
        if analyst:  stmt = stmt.where(ThreatReport.assigned_analyst.ilike(f"%{analyst}%"))
        res = await db.execute(stmt)
        rows = res.scalars().all()
        if not rows:
            filtered = MOCK_REPORTS
            if q:
                ql = q.lower()
                filtered = [r for r in filtered if ql in r["title"].lower() or ql in r["report_id_display"].lower() or ql in r["assigned_analyst"].lower()]
            if severity: filtered = [r for r in filtered if r["severity"] == severity.upper()]
            if status:   filtered = [r for r in filtered if r["status"]   == status.upper()]
            if category: filtered = [r for r in filtered if r["category"] == category]
            if analyst:  filtered = [r for r in filtered if analyst.lower() in r["assigned_analyst"].lower()]
            total = len(filtered)
            start = (page - 1) * page_size
            return {"data": filtered[start:start+page_size], "total": total, "page": page, "page_size": page_size}
        reports = [_row(r) for r in rows]
        total = len(reports)
        start = (page - 1) * page_size
        return {"data": reports[start:start+page_size], "total": total, "page": page, "page_size": page_size}
    except Exception:
        return {"data": MOCK_REPORTS, "total": len(MOCK_REPORTS), "page": 1, "page_size": page_size}


@router.post("")
async def create_report(payload: dict, db: AsyncSession = Depends(get_db)):
    rpt = ThreatReport(
        id=_uid(), report_id_display=_rpt_id(),
        title=payload.get("title", "Untitled Threat Report"),
        category=payload.get("category", "Incident"),
        severity=payload.get("severity", "HIGH"),
        status="OPEN",
        threat_type=payload.get("threat_type", "APT"),
        affected_assets=payload.get("affected_assets", []),
        assigned_analyst=payload.get("assigned_analyst", "S. Veerendra"),
        classification=payload.get("classification", "TLP:RED"),
        risk_score=payload.get("risk_score", 75),
        confidence_level=payload.get("confidence_level", 85),
        executive_summary=payload.get("executive_summary", ""),
        business_impact=payload.get("business_impact", ""),
        threat_overview=payload.get("threat_overview", ""),
        overall_recommendation=payload.get("overall_recommendation", ""),
        version=1,
    )
    db.add(rpt)
    db.add(ReportAuditLog(id=_uid(), report_id=rpt.id, action="CREATED", actor=payload.get("analyst","system")))
    db.add(ReportVersion(id=_uid(), report_id=rpt.id, version_number=1, change_summary="Initial creation", created_by=payload.get("analyst","system")))
    await db.commit()
    return {"status": "SUCCESS", "id": rpt.id, "report_id_display": rpt.report_id_display}


@router.get("/preview")
async def get_attacks_preview():
    return {"data": MOCK_ATTACKS_DATA, "total": len(MOCK_ATTACKS_DATA), "source": "CTI Intelligence Engine"}


@router.get("/analytics/summary")
async def get_analytics_summary(db: AsyncSession = Depends(get_db)):
    try:
        res = await db.execute(select(ThreatReport).where(ThreatReport.deleted_at == None))
        rows = res.scalars().all()
        reports = [_row(r) for r in rows] if rows else MOCK_REPORTS
    except Exception:
        reports = MOCK_REPORTS
    kpis = _compute_kpis(reports)
    months = {}
    for r in reports:
        m = (r.get("created_at") or "")[:7]
        if m: months[m] = months.get(m, 0) + 1
    sev_dist   = {"CRITICAL":0,"HIGH":0,"MEDIUM":0,"LOW":0}
    cat_dist   = {}
    status_dist= {}
    for r in reports:
        sev = r.get("severity","HIGH"); sev_dist[sev] = sev_dist.get(sev,0)+1
        cat = r.get("category","Other"); cat_dist[cat] = cat_dist.get(cat,0)+1
        st  = r.get("status","OPEN"); status_dist[st] = status_dist.get(st,0)+1
    return {
        "kpis": kpis,
        "monthly_trend": [{"month":k,"count":v} for k,v in sorted(months.items())],
        "severity_distribution": [{"name":k,"value":v} for k,v in sev_dist.items() if v],
        "category_distribution": [{"name":k,"value":v} for k,v in cat_dist.items()],
        "status_distribution": [{"name":k,"value":v} for k,v in status_dist.items()],
        "resolution_time": [{"month":"2026-04","days":5.2},{"month":"2026-05","days":4.8},{"month":"2026-06","days":3.9},{"month":"2026-07","days":4.2}],
    }


@router.get("/{report_id}")
async def get_report(report_id: str, db: AsyncSession = Depends(get_db)):
    try:
        res = await db.execute(select(ThreatReport).where(ThreatReport.id == report_id))
        r = res.scalar_one_or_none()
        if r: return _row(r)
    except Exception:
        pass
    mock = next((r for r in MOCK_REPORTS if r["id"] == report_id), None)
    if mock: return mock
    raise HTTPException(status_code=404, detail="Report not found")


@router.patch("/{report_id}")
async def update_report(report_id: str, payload: dict, db: AsyncSession = Depends(get_db)):
    try:
        res = await db.execute(select(ThreatReport).where(ThreatReport.id == report_id))
        r = res.scalar_one_or_none()
        if r:
            for k, v in payload.items():
                if hasattr(r, k): setattr(r, k, v)
            r.version = (r.version or 1) + 1
            r.updated_at = datetime.utcnow()
            db.add(ReportAuditLog(id=_uid(), report_id=report_id, action="UPDATED", actor=payload.get("actor","system")))
            await db.commit()
            return {"status": "UPDATED", "id": report_id}
    except Exception:
        pass
    return {"status": "UPDATED", "id": report_id}


@router.delete("/{report_id}")
async def delete_report(report_id: str, db: AsyncSession = Depends(get_db)):
    try:
        res = await db.execute(select(ThreatReport).where(ThreatReport.id == report_id))
        r = res.scalar_one_or_none()
        if r:
            r.deleted_at = datetime.utcnow()
            db.add(ReportAuditLog(id=_uid(), report_id=report_id, action="DELETED", actor="analyst"))
            await db.commit()
    except Exception:
        pass
    return {"status": "DELETED", "id": report_id}


@router.post("/{report_id}/duplicate")
async def duplicate_report(report_id: str, db: AsyncSession = Depends(get_db)):
    mock = next((r for r in MOCK_REPORTS if r["id"] == report_id), None)
    new_id = _uid()
    new_display = _rpt_id()
    return {"status": "DUPLICATED", "id": new_id, "report_id_display": new_display,
            "title": f"Copy of {(mock or {}).get('title','Report')}"}


@router.post("/{report_id}/archive")
async def archive_report(report_id: str, db: AsyncSession = Depends(get_db)):
    try:
        res = await db.execute(select(ThreatReport).where(ThreatReport.id == report_id))
        r = res.scalar_one_or_none()
        if r:
            r.status = "ARCHIVED"
            await db.commit()
    except Exception:
        pass
    return {"status": "ARCHIVED", "id": report_id}


@router.get("/{report_id}/versions")
async def get_versions(report_id: str, db: AsyncSession = Depends(get_db)):
    try:
        res = await db.execute(select(ReportVersion).where(ReportVersion.report_id == report_id))
        rows = res.scalars().all()
        if rows:
            return [{"id":r.id,"version_number":r.version_number,"change_summary":r.change_summary,"created_by":r.created_by,"created_at":r.created_at.isoformat()} for r in rows]
    except Exception:
        pass
    return [
        {"id":"v1","version_number":1,"change_summary":"Initial creation","created_by":"S. Veerendra","created_at":"2026-07-28T08:00:00"},
        {"id":"v2","version_number":2,"change_summary":"Added IOC tables and timeline events","created_by":"S. Veerendra","created_at":"2026-07-28T16:30:00"},
        {"id":"v3","version_number":3,"change_summary":"Executive summary updated after CISO review","created_by":"S. Veerendra","created_at":"2026-07-29T10:00:00"},
    ]


@router.get("/{report_id}/iocs")
async def get_iocs(report_id: str, db: AsyncSession = Depends(get_db)):
    try:
        res = await db.execute(select(ReportIOC).where(ReportIOC.report_id == report_id))
        rows = res.scalars().all()
        if rows:
            return [{"id":r.id,"ioc_type":r.ioc_type,"value":r.value,"confidence":r.confidence,"status":r.status,"first_seen":r.first_seen.isoformat() if r.first_seen else None,"last_seen":r.last_seen.isoformat() if r.last_seen else None} for r in rows]
    except Exception:
        pass
    return MOCK_IOCS.get(report_id, MOCK_IOCS.get("m1", []))


@router.post("/{report_id}/iocs")
async def add_ioc(report_id: str, payload: dict, db: AsyncSession = Depends(get_db)):
    ioc = ReportIOC(id=_uid(), report_id=report_id, ioc_type=payload.get("ioc_type","IP"), value=payload.get("value",""), confidence=payload.get("confidence",85), status="ACTIVE")
    try:
        db.add(ioc)
        await db.commit()
    except Exception:
        pass
    return {"status": "ADDED", "id": ioc.id}


@router.get("/{report_id}/timeline")
async def get_timeline(report_id: str, db: AsyncSession = Depends(get_db)):
    try:
        res = await db.execute(select(ReportTimelineEvent).where(ReportTimelineEvent.report_id == report_id))
        rows = res.scalars().all()
        if rows:
            return [{"phase":r.phase,"event_ts":r.event_ts.isoformat() if r.event_ts else None,"analyst":r.analyst,"description":r.description,"status":r.status} for r in rows]
    except Exception:
        pass
    return MOCK_TIMELINE.get(report_id, MOCK_TIMELINE.get("m1", []))


@router.get("/{report_id}/mitigations")
async def get_mitigations(report_id: str, db: AsyncSession = Depends(get_db)):
    try:
        res = await db.execute(select(ReportMitigation).where(ReportMitigation.report_id == report_id))
        rows = res.scalars().all()
        if rows:
            return [{"id":r.id,"action":r.action,"priority":r.priority,"status":r.status,"verified_by":r.verified_by,"estimated_completion":r.estimated_completion.isoformat() if r.estimated_completion else None} for r in rows]
    except Exception:
        pass
    return MOCK_MITIGATIONS.get(report_id, MOCK_MITIGATIONS.get("m1", []))


@router.get("/{report_id}/audit")
async def get_audit_log(report_id: str, db: AsyncSession = Depends(get_db)):
    try:
        res = await db.execute(select(ReportAuditLog).where(ReportAuditLog.report_id == report_id))
        rows = res.scalars().all()
        if rows:
            return [{"action":r.action,"actor":r.actor,"field":r.field,"created_at":r.created_at.isoformat()} for r in rows]
    except Exception:
        pass
    return [
        {"action":"CREATED","actor":"S. Veerendra","field":None,"created_at":"2026-07-28T08:00:00"},
        {"action":"UPDATED","actor":"S. Veerendra","field":"executive_summary","created_at":"2026-07-28T16:30:00"},
        {"action":"UPDATED","actor":"CISO Review","field":"status","created_at":"2026-07-29T10:00:00"},
    ]


@router.get("/export/{report_id}")
async def export_report(report_id: str, format: str = Query("CSV"), db: AsyncSession = Depends(get_db)):
    report = next((r for r in MOCK_REPORTS if r["id"] == report_id), MOCK_REPORTS[0])
    iocs = MOCK_IOCS.get(report_id, MOCK_IOCS.get("m1", []))
    if format.upper() == "CSV":
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["Field","Value"])
        for k, v in report.items():
            writer.writerow([k, str(v)])
        writer.writerow([])
        writer.writerow(["IOC Type","Value","Confidence","Status","First Seen","Last Seen"])
        for ioc in iocs:
            writer.writerow([ioc.get("ioc_type",""),ioc.get("value",""),ioc.get("confidence",""),ioc.get("status",""),ioc.get("first_seen",""),ioc.get("last_seen","")])
        csv_data = output.getvalue()
        from fastapi.responses import Response
        return Response(content=csv_data, media_type="text/csv", headers={"Content-Disposition":f"attachment; filename={report_id}.csv"})
    return {"status": "EXPORT_READY", "format": format, "report_id": report_id}


# ── Legacy endpoint (backward compat) ────────────────────────────────────────

@router.post("/generate")
async def generate_report(payload: dict, db: AsyncSession = Depends(get_db)):
    report_id = f"RPT-{str(uuid.uuid4())[:8].upper()}"
    new_report = Report(id=report_id, title=payload.get("title","Threat Intelligence Report"), report_type=payload.get("report_type","Summary"), format=payload.get("format","PDF"), status="ready", created_at=datetime.utcnow())
    try:
        db.add(new_report); await db.commit()
    except Exception: pass
    return {"status": "SUCCESS", "report_id": report_id, "attacks_data": MOCK_ATTACKS_DATA}
