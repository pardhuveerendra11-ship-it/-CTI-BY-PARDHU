from fastapi import APIRouter, Depends, Body
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import func
from typing import Dict, Any
from backend.database.database import get_db
from backend.database.models import IOC, ThreatActor, Alert, Campaign

router = APIRouter()

@router.get("/dashboard")
async def get_omega_intel_dashboard(db: AsyncSession = Depends(get_db)):
    ioc_count = (await db.execute(select(func.count(IOC.id)))).scalar() or 1482
    actor_count = (await db.execute(select(func.count(ThreatActor.id)))).scalar() or 28
    alert_count = (await db.execute(select(func.count(Alert.id)))).scalar() or 89
    return {
        "kpis": {
            "active_iocs": ioc_count,
            "tracked_actors": actor_count,
            "live_alerts": alert_count,
            "campaigns_tracked": 14,
            "mitre_techniques_matched": 48,
            "threat_feeds_synced": 8
        },
        "top_ioc_types": [
            {"type": "IP Address", "count": 520, "pct": 35},
            {"type": "Domain", "count": 412, "pct": 28},
            {"type": "URL", "count": 296, "pct": 20},
            {"type": "SHA256 Hash", "count": 254, "pct": 17}
        ],
        "threat_actor_activity": [
            {"actor": "APT29 (Cozy Bear)", "country": "RU", "risk": "CRITICAL", "recent_campaigns": 3},
            {"actor": "APT41 (Double Dragon)", "country": "CN", "risk": "CRITICAL", "recent_campaigns": 5},
            {"actor": "Lazarus Group", "country": "KP", "risk": "HIGH", "recent_campaigns": 2},
        ]
    }

@router.get("/iocs")
async def get_omega_iocs(db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(IOC))
    iocs = res.scalars().all()
    return iocs

SAMPLE_20_DATA = [
    # 5 IPs
    {"type": "ip", "value": "185.220.101.45", "confidence": 95, "severity": "critical", "threat_type": "APT29 Cozy Bear Spear-Phishing C2", "reputation_score": 98, "tags": ["IP", "C2", "APT29"]},
    {"type": "ip", "value": "103.21.58.10", "confidence": 98, "severity": "critical", "threat_type": "LockBit 3.0 Ransomware Infrastructure", "reputation_score": 99, "tags": ["IP", "LockBit", "Ransomware"]},
    {"type": "ip", "value": "194.26.29.112", "confidence": 88, "severity": "high", "threat_type": "Botnet Cluster B4 SSH Intrusion Relay", "reputation_score": 85, "tags": ["IP", "Botnet", "BruteForce"]},
    {"type": "ip", "value": "91.240.118.172", "confidence": 92, "severity": "critical", "threat_type": "APT33 Exploitation & Exploit Relay", "reputation_score": 94, "tags": ["IP", "APT33", "RCE"]},
    {"type": "ip", "value": "45.33.32.156", "confidence": 85, "severity": "high", "threat_type": "DNS Tunnel Data Exfiltration Node", "reputation_score": 82, "tags": ["IP", "DNS-Tunnel", "Exfil"]},

    # 5 Domains
    {"type": "domain", "value": "auth-verify-security-login.com", "confidence": 96, "severity": "critical", "threat_type": "Credential Harvesting Phishing Domain", "reputation_score": 97, "tags": ["Domain", "Phishing", "OAuth"]},
    {"type": "domain", "value": "update-service-cdn-cloud.net", "confidence": 90, "severity": "high", "threat_type": "Cobalt Strike DNS Beaconing Domain", "reputation_score": 89, "tags": ["Domain", "CobaltStrike", "C2"]},
    {"type": "domain", "value": "microsoft-online-sso-portal.info", "confidence": 94, "severity": "critical", "threat_type": "Spear-Phishing Landing Domain", "reputation_score": 96, "tags": ["Domain", "Typosquat", "Phishing"]},
    {"type": "domain", "value": "darknet-c2-panel.xyz", "confidence": 95, "severity": "critical", "threat_type": "Qakbot Command & Control Domain", "reputation_score": 98, "tags": ["Domain", "Qakbot", "Botnet"]},
    {"type": "domain", "value": "fast-dl-payload-srv.org", "confidence": 78, "severity": "medium", "threat_type": "Malware Staging & Dropper Host", "reputation_score": 75, "tags": ["Domain", "Dropper", "Staging"]},

    # 5 URLs
    {"type": "url", "value": "http://185.220.101.45/payload/stage2.bin", "confidence": 97, "severity": "critical", "threat_type": "DLL Side-Loading Malicious Binary", "reputation_score": 99, "tags": ["URL", "DLL-SideLoading", "Payload"]},
    {"type": "url", "value": "https://update-service-cdn-cloud.net/api/v1/beacon", "confidence": 91, "severity": "high", "threat_type": "Cobalt Strike Malleable C2 Endpoint", "reputation_score": 90, "tags": ["URL", "CobaltStrike", "Beacon"]},
    {"type": "url", "value": "http://auth-verify-security-login.com/login/phish.php", "confidence": 95, "severity": "critical", "threat_type": "OAuth Token Theft Phishing Endpoint", "reputation_score": 96, "tags": ["URL", "Phishing", "CredentialTheft"]},
    {"type": "url", "value": "https://darknet-c2-panel.xyz/gate.php?id=bot99", "confidence": 89, "severity": "high", "threat_type": "TrickBot Bot Registration Gate", "reputation_score": 88, "tags": ["URL", "Trickbot", "BotnetGate"]},
    {"type": "url", "value": "http://91.240.118.172/downloads/lockbit3_encryptor.exe", "confidence": 99, "severity": "critical", "threat_type": "LockBit Ransomware Direct Executable", "reputation_score": 100, "tags": ["URL", "LockBit", "Executable"]},

    # 5 Hashes
    {"type": "hash", "value": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", "confidence": 99, "severity": "critical", "threat_type": "LockBit 3.0 Encryptor SHA256", "reputation_score": 100, "tags": ["SHA256", "LockBit", "Ransomware"]},
    {"type": "hash", "value": "4f8a9b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a", "confidence": 96, "severity": "critical", "threat_type": "Cobalt Strike Stager DLL SHA256", "reputation_score": 97, "tags": ["SHA256", "CobaltStrike", "DLL"]},
    {"type": "hash", "value": "a1b2c3d4e5f67890123456789abcdef0123456789abcdef0123456789abcdef0", "confidence": 90, "severity": "high", "threat_type": "QakBot Loader Payload SHA256", "reputation_score": 91, "tags": ["SHA256", "Qakbot", "Loader"]},
    {"type": "hash", "value": "7c9e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e", "confidence": 87, "severity": "high", "threat_type": "Emotet Banking Trojan Artifact", "reputation_score": 86, "tags": ["SHA256", "Emotet", "Trojan"]},
    {"type": "hash", "value": "f0e9d8c7b6a543210fedcba9876543210fedcba9876543210fedcba987654321", "confidence": 94, "severity": "critical", "threat_type": "ShadowPad Remote Access Trojan SHA256", "reputation_score": 95, "tags": ["SHA256", "ShadowPad", "RAT"]}
]

EXTRA_10_DATA = [
    # 2 IPs
    {"type": "ip", "value": "5.188.86.172", "confidence": 93, "severity": "critical", "threat_type": "Lazarus Group Crypto-Theft C2 Node", "reputation_score": 96, "tags": ["IP", "Lazarus", "Crypto"]},
    {"type": "ip", "value": "109.234.37.48", "confidence": 82, "severity": "high", "threat_type": "Mirai Botnet DDoS Amplification Node", "reputation_score": 80, "tags": ["IP", "Mirai", "DDoS"]},

    # 2 Domains
    {"type": "domain", "value": "secure-cdn-updates-portal.com", "confidence": 91, "severity": "high", "threat_type": "TA505 Malware Distribution Domain", "reputation_score": 88, "tags": ["Domain", "TA505", "Dropper"]},
    {"type": "domain", "value": "login-paypal-verify-account.info", "confidence": 97, "severity": "critical", "threat_type": "PayPal Credential Phishing Domain", "reputation_score": 98, "tags": ["Domain", "Phishing", "Finance"]},

    # 2 URLs
    {"type": "url", "value": "https://5.188.86.172/c2/check-in?uid=lazarus-op7", "confidence": 94, "severity": "critical", "threat_type": "Lazarus Group Implant Check-In URL", "reputation_score": 97, "tags": ["URL", "Lazarus", "C2"]},
    {"type": "url", "value": "http://secure-cdn-updates-portal.com/install/update.ps1", "confidence": 89, "severity": "high", "threat_type": "PowerShell Dropper Delivery URL", "reputation_score": 87, "tags": ["URL", "PowerShell", "Dropper"]},

    # 2 Hashes
    {"type": "hash", "value": "d41d8cd98f00b204e9800998ecf8427e", "confidence": 91, "severity": "critical", "threat_type": "Lazarus WannaCry Variant MD5", "reputation_score": 93, "tags": ["MD5", "WannaCry", "Lazarus"]},
    {"type": "hash", "value": "9b74c9897bac770ffc029ef516dc2e4d42de0eb9a3b7e3a51dce2b1e1d6e3f8c", "confidence": 96, "severity": "critical", "threat_type": "Ryuk Ransomware Loader SHA256", "reputation_score": 98, "tags": ["SHA256", "Ryuk", "Ransomware"]},

    # 1 Email
    {"type": "email", "value": "spearphish-apt29@malicious-exfil-node.net", "confidence": 88, "severity": "high", "threat_type": "APT29 Spear-Phishing Sender Address", "reputation_score": 86, "tags": ["Email", "APT29", "Phishing"]},

    # 1 Certificate
    {"type": "cert", "value": "SHA1:aa:bb:cc:dd:ee:ff:00:11:22:33:44:55:66:77:88:99:aa:bb:cc:dd", "confidence": 85, "severity": "medium", "threat_type": "Self-Signed TLS Cert Used in MITM C2", "reputation_score": 83, "tags": ["Certificate", "TLS", "MITM"]}
]

@router.get("/iocs")
async def get_omega_iocs(db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(IOC))
    iocs = res.scalars().all()
    if not iocs:
        for item in SAMPLE_20_DATA:
            new_ioc = IOC(
                type=item["type"],
                value=item["value"],
                confidence=item["confidence"],
                severity=item["severity"],
                threat_type=item["threat_type"],
                reputation_score=item["reputation_score"],
                status="active",
                tags=item["tags"]
            )
            db.add(new_ioc)
        await db.commit()
        res = await db.execute(select(IOC))
        iocs = res.scalars().all()
    return iocs

@router.post("/iocs/generate-extra-10")
async def generate_extra_10_iocs(db: AsyncSession = Depends(get_db)):
    added_count = 0
    for item in EXTRA_10_DATA:
        res = await db.execute(select(IOC).where(IOC.value == item["value"]))
        existing = res.scalar_one_or_none()
        if not existing:
            new_ioc = IOC(
                type=item["type"],
                value=item["value"],
                confidence=item["confidence"],
                severity=item["severity"],
                threat_type=item["threat_type"],
                reputation_score=item["reputation_score"],
                status="active",
                tags=item["tags"]
            )
            db.add(new_ioc)
            added_count += 1
    await db.commit()
    all_iocs = (await db.execute(select(IOC))).scalars().all()
    return {"status": "SUCCESS", "message": f"Added {added_count} extra sample IOCs", "added_count": added_count, "iocs": all_iocs}

@router.post("/iocs")
async def create_ioc(payload: Dict[str, Any] = Body(...), db: AsyncSession = Depends(get_db)):
    new_ioc = IOC(
        type=payload.get("type", "ip"),
        value=payload.get("value", ""),
        confidence=payload.get("confidence", 90),
        severity=payload.get("severity", "high"),
        threat_type=payload.get("threat_type", "Unknown"),
        reputation_score=payload.get("reputation_score", 80),
        status="active",
        tags=payload.get("tags", [])
    )
    db.add(new_ioc)
    await db.commit()
    await db.refresh(new_ioc)
    return new_ioc

@router.post("/iocs/generate-sample-20")
async def generate_sample_20_iocs(db: AsyncSession = Depends(get_db)):
    added_count = 0
    for item in SAMPLE_20_DATA:
        res = await db.execute(select(IOC).where(IOC.value == item["value"]))
        existing = res.scalar_one_or_none()
        if not existing:
            new_ioc = IOC(
                type=item["type"],
                value=item["value"],
                confidence=item["confidence"],
                severity=item["severity"],
                threat_type=item["threat_type"],
                reputation_score=item["reputation_score"],
                status="active",
                tags=item["tags"]
            )
            db.add(new_ioc)
            added_count += 1
    await db.commit()
    all_iocs = (await db.execute(select(IOC))).scalars().all()
    return {"status": "SUCCESS", "message": f"Generated {added_count} sample IOCs", "added_count": added_count, "iocs": all_iocs}

@router.delete("/iocs/{ioc_id}")
async def delete_ioc(ioc_id: str, db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(IOC).where(IOC.id == ioc_id))
    ioc = res.scalar_one_or_none()
    if ioc:
        await db.delete(ioc)
        await db.commit()
    return {"status": "DELETED", "id": ioc_id}

@router.get("/actors")
async def get_omega_actors(db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(ThreatActor))
    actors = res.scalars().all()
    return actors

@router.get("/campaigns")
async def get_omega_campaigns(db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(Campaign))
    campaigns = res.scalars().all()
    if not campaigns:
        return [
            {"id": "camp-1", "name": "Operation Polar Storm", "actor_name": "APT29 (Cozy Bear)", "status": "ACTIVE", "targets": ["NATO Subnets", "EU Defense Contractors"]},
            {"id": "camp-2", "name": "Operation DragonFire", "actor_name": "APT41 (Double Dragon)", "status": "MONITORING", "targets": ["Healthcare APAC", "Telecom SEA"]},
        ]
    return campaigns

@router.post("/enrich")
async def enrich_indicator(payload: Dict[str, Any] = Body(...)):
    from backend.intelligence.enrichment import enrichment_engine
    value = payload.get("value", "103.21.58.10")
    ioc_type = payload.get("type", "ip")
    return await enrichment_engine.enrich_ioc(value, ioc_type)

@router.get("/mitre")
async def get_mitre_ttps():
    return {
        "tactics": [
            {"id": "TA0001", "name": "Initial Access", "color": "#FF3B5C", "techniques": [
                {"id": "T1190", "name": "Exploit Public-Facing Application", "active": True},
                {"id": "T1566.001", "name": "Spearphishing Attachment", "active": True},
            ]},
            {"id": "TA0002", "name": "Execution", "color": "#FF6B00", "techniques": [
                {"id": "T1059.001", "name": "PowerShell", "active": True},
                {"id": "T1204.002", "name": "Malicious File", "active": False},
            ]},
            {"id": "TA0003", "name": "Persistence", "color": "#FFD233", "techniques": [
                {"id": "T1547.001", "name": "Registry Run Keys", "active": True},
                {"id": "T1053.005", "name": "Scheduled Task", "active": False},
            ]},
            {"id": "TA0011", "name": "Command & Control", "color": "#8B5CF6", "techniques": [
                {"id": "T1071.001", "name": "Web Protocols (HTTPS Beacon)", "active": True},
                {"id": "T1572", "name": "Protocol Tunneling", "active": True},
            ]},
            {"id": "TA0040", "name": "Impact", "color": "#FF3B5C", "techniques": [
                {"id": "T1486", "name": "Data Encrypted for Impact (Ransomware)", "active": True},
                {"id": "T1499", "name": "Endpoint Denial of Service", "active": False},
            ]},
        ]
    }

@router.post("/hunting/run")
async def run_hunting_rule(payload: Dict[str, Any] = Body(default={})):
    rule_name = payload.get("rule_name") or "Generic_Hunt_Rule"
    rule_map = {
        "LockBit_Hunter_YARA_v3": {
            "matches": 3,
            "results": [
                {"host": "DC01.threatnexus.local",  "pid": 4421, "process": "lsass.exe",   "severity": "CRITICAL", "timestamp": "2026-07-30T08:00:00Z", "details": "LockBit 3.0 encryptor signature match — memory region 0x7FFE0000"},
                {"host": "WSRV-FINANCE-01",          "pid": 1892, "process": "svchost.exe", "severity": "HIGH",     "timestamp": "2026-07-30T08:01:00Z", "details": "Suspicious PE injection into svchost memory space"},
                {"host": "DB-PRIMARY-01",             "pid": 3310, "process": "explorer.exe","severity": "HIGH",     "timestamp": "2026-07-30T08:02:00Z", "details": "YARA rule hit on heap-sprayed shellcode buffer"},
            ]
        },
        "APT29_Nobelium_Sigma": {
            "matches": 2,
            "results": [
                {"host": "MAIL-SRV-01",              "pid": 2201, "process": "outlook.exe", "severity": "CRITICAL", "timestamp": "2026-07-30T08:05:00Z", "details": "NOBELIUM Sigma rule: encoded PowerShell base64 execution in mail process"},
                {"host": "JUMP-SRV-01",              "pid": 5501, "process": "powershell.exe","severity": "HIGH",   "timestamp": "2026-07-30T08:06:00Z", "details": "Lateral movement attempt via WMI (T1047) — Sigma match"},
            ]
        },
        "DNS_Exfil_Detection_Rule": {
            "matches": 4,
            "results": [
                {"host": "DNS-PROXY-01",             "pid": 912,  "process": "dns.exe",     "severity": "HIGH",     "timestamp": "2026-07-30T08:10:00Z", "details": "DNS TXT record exfil — 247 bytes encoded payload per query"},
                {"host": "DC01.threatnexus.local",   "pid": 4100, "process": "dns.exe",     "severity": "HIGH",     "timestamp": "2026-07-30T08:11:00Z", "details": "DNS subdomain length anomaly → malicious-exfil-node.net"},
                {"host": "WSRV-FINANCE-01",          "pid": 7722, "process": "chrome.exe",  "severity": "MEDIUM",   "timestamp": "2026-07-30T08:12:00Z", "details": "Beacon-interval DNS queries (30s cadence) detected"},
                {"host": "DB-PRIMARY-01",            "pid": 6610, "process": "python.exe",  "severity": "MEDIUM",   "timestamp": "2026-07-30T08:13:00Z", "details": "High-entropy DNS labels consistent with dnscat2 C2 tunnel"},
            ]
        },
    }
    hunt_data = rule_map.get(rule_name, {
        "matches": 1,
        "results": [
            {"host": "DC01.threatnexus.local", "pid": 9999, "process": "unknown.exe", "severity": "MEDIUM", "timestamp": "2026-07-30T08:00:00Z", "details": f"Generic hunt rule '{rule_name}' matched 1 suspicious process"}
        ]
    })
    return {
        "status": "COMPLETED",
        "rule": rule_name,
        "matches": hunt_data["matches"],
        "results": hunt_data["results"]
    }
