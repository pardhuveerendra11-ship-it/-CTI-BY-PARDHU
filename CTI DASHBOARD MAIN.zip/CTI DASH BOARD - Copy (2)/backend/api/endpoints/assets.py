import random
from typing import Any
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from backend.database.database import get_db
from backend.database.models import Asset

router = APIRouter()

# ── 15 realistic enterprise assets ──────────────────────────────────────────
SAMPLE_ASSETS = [
    {"name": "DC01-PRIMARY",         "ip_address": "10.0.0.5",    "asset_type": "Domain Controller", "os_version": "Windows Server 2022",   "criticality": "MISSION_CRITICAL", "status": "ACTIVE",      "owner": "IT-OPS",    "location": "Mumbai DC1",     "tags": ["AD","Kerberos","LDAP"],        "patch_level": "97%"},
    {"name": "FINSVR-DB-01",          "ip_address": "10.0.1.12",   "asset_type": "Database Server",   "os_version": "RHEL 9.3",             "criticality": "MISSION_CRITICAL", "status": "COMPROMISED", "owner": "Finance-IT", "location": "Mumbai DC1",     "tags": ["Oracle","Finance","PCI"],     "patch_level": "71%"},
    {"name": "MAIL-SRV-01",           "ip_address": "10.0.1.20",   "asset_type": "Mail Server",       "os_version": "Windows Server 2019",   "criticality": "HIGH",             "status": "ACTIVE",      "owner": "IT-OPS",    "location": "Bangalore DC2",  "tags": ["Exchange","MX","SMTP"],       "patch_level": "89%"},
    {"name": "JUMP-SRV-ADMIN",        "ip_address": "10.0.0.100",  "asset_type": "Jump Host",         "os_version": "Ubuntu 22.04 LTS",      "criticality": "MISSION_CRITICAL", "status": "ACTIVE",      "owner": "SecOps",    "location": "Mumbai DC1",     "tags": ["PAM","Bastion","RDP"],        "patch_level": "100%"},
    {"name": "WSRV-FINANCE-01",       "ip_address": "10.1.10.55",  "asset_type": "Workstation",       "os_version": "Windows 11 22H2",       "criticality": "HIGH",             "status": "COMPROMISED", "owner": "Finance",   "location": "HQ Floor 3",     "tags": ["Endpoint","Finance"],         "patch_level": "60%"},
    {"name": "WSRV-HR-02",            "ip_address": "10.1.11.33",  "asset_type": "Workstation",       "os_version": "Windows 10 LTSC",       "criticality": "MEDIUM",           "status": "ACTIVE",      "owner": "HR",        "location": "HQ Floor 2",     "tags": ["Endpoint","HR"],              "patch_level": "83%"},
    {"name": "WEB-DMZ-01",            "ip_address": "203.0.113.10","asset_type": "Web Server",        "os_version": "Debian 12 (Nginx)",     "criticality": "HIGH",             "status": "ACTIVE",      "owner": "DevOps",    "location": "DMZ Zone A",     "tags": ["Nginx","Public","WAF"],       "patch_level": "92%"},
    {"name": "FW-PERIMETER-NGFW",     "ip_address": "203.0.113.1", "asset_type": "Firewall",          "os_version": "FortiOS 7.6.1",         "criticality": "MISSION_CRITICAL", "status": "PROTECTED",   "owner": "NetSec",    "location": "Edge DC",        "tags": ["NGFW","IPS","SD-WAN"],        "patch_level": "100%"},
    {"name": "SIEM-SOC-SRV",          "ip_address": "10.0.2.5",    "asset_type": "SIEM Server",       "os_version": "Ubuntu 22.04 LTS",      "criticality": "MISSION_CRITICAL", "status": "PROTECTED",   "owner": "SecOps",    "location": "Mumbai DC1",     "tags": ["Splunk","SIEM","LogMgmt"],   "patch_level": "99%"},
    {"name": "BACKUP-NAS-01",         "ip_address": "10.0.3.10",   "asset_type": "NAS / Backup",      "os_version": "TrueNAS SCALE 24.04",   "criticality": "HIGH",             "status": "ACTIVE",      "owner": "IT-OPS",    "location": "Bangalore DC2",  "tags": ["NAS","Backup","ZFS"],         "patch_level": "78%"},
    {"name": "K8S-MASTER-01",         "ip_address": "10.10.0.1",   "asset_type": "Kubernetes Master", "os_version": "Ubuntu 24.04 LTS",      "criticality": "HIGH",             "status": "ACTIVE",      "owner": "DevOps",    "location": "Cloud (AWS ap-south-1)", "tags": ["K8s","Container","CI-CD"],    "patch_level": "95%"},
    {"name": "IOT-CAM-LOBBY",         "ip_address": "192.168.5.11","asset_type": "IoT Device",        "os_version": "Hikvision FW 5.7.8",    "criticality": "LOW",              "status": "ACTIVE",      "owner": "Facilities","location": "HQ Lobby",       "tags": ["IoT","CCTV"],                 "patch_level": "40%"},
    {"name": "VPN-GATEWAY-01",        "ip_address": "203.0.113.25","asset_type": "VPN Gateway",       "os_version": "Cisco ASA 9.19.1",      "criticality": "MISSION_CRITICAL", "status": "PROTECTED",   "owner": "NetSec",    "location": "Edge DC",        "tags": ["VPN","IPSec","SSL-VPN"],     "patch_level": "100%"},
    {"name": "DEVOPS-JENKINS-01",     "ip_address": "10.10.1.50",  "asset_type": "CI/CD Server",      "os_version": "Amazon Linux 2023",     "criticality": "HIGH",             "status": "ACTIVE",      "owner": "DevOps",    "location": "Cloud (AWS ap-south-1)", "tags": ["Jenkins","CI-CD","Build"],   "patch_level": "85%"},
    {"name": "PRINTER-EXEC-FLOOR4",   "ip_address": "192.168.4.88","asset_type": "Printer",           "os_version": "HP FW 5.7.0.4",         "criticality": "LOW",              "status": "ACTIVE",      "owner": "Facilities","location": "HQ Floor 4",     "tags": ["Printer","Network"],          "patch_level": "22%"},
]

ATTACK_VECTORS = [
    "Spear-Phishing Payload Dropped",
    "LockBit 3.0 Ransomware Beacon",
    "Pass-the-Hash NTLM Relay",
    "Kerberoasting SPN Flood",
    "PowerShell Base64 Injection",
    "DNS TXT Record Exfiltration",
    "SQL Injection Attempt",
    "Lateral Movement via RDP",
    "Credential Stuffing Attack",
    "Cobalt Strike Beacon Detected",
]

def _enrich(asset: dict, idx: int) -> dict:
    """Attach attack / risk telemetry to a dict asset record."""
    if asset["status"] == "COMPROMISED":
        attack   = ATTACK_VECTORS[idx % len(ATTACK_VECTORS)]
        risk     = random.randint(72, 96)
    else:
        attack   = "None"
        risk     = random.randint(8, 35)
    return {**asset, "active_attack": attack, "compromise_score": risk}


@router.get("")
async def get_assets(db: AsyncSession = Depends(get_db)):
    res    = await db.execute(select(Asset))
    assets = res.scalars().all()

    if not assets:
        # Auto-seed if table is empty
        for item in SAMPLE_ASSETS:
            db.add(Asset(**{k: v for k, v in item.items()
                            if k in Asset.__table__.columns.keys()}))
        await db.commit()
        res    = await db.execute(select(Asset))
        assets = res.scalars().all()

    rows = [dict(a.__dict__) for a in assets]
    for row in rows:
        row.pop("_sa_instance_state", None)
    return [_enrich(r, i) for i, r in enumerate(rows)]


@router.post("/generate-sample")
async def generate_sample_assets(db: AsyncSession = Depends(get_db)):
    """Insert all 15 sample assets (skip duplicates by name)."""
    res      = await db.execute(select(Asset))
    existing = {a.name for a in res.scalars().all()}

    added = 0
    for item in SAMPLE_ASSETS:
        if item["name"] not in existing:
            db.add(Asset(**{k: v for k, v in item.items()
                            if k in Asset.__table__.columns.keys()}))
            added += 1
    await db.commit()
    return {"message": f"Added {added} sample assets", "total": len(SAMPLE_ASSETS)}


@router.post("")
async def create_asset(data: dict, db: AsyncSession = Depends(get_db)):
    """Create a new asset."""
    asset = Asset(**{k: v for k, v in data.items()
                     if k in Asset.__table__.columns.keys()})
    db.add(asset)
    await db.commit()
    await db.refresh(asset)
    return asset
