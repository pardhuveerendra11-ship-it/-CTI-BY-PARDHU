import uuid
from datetime import datetime
from sqlalchemy import Column, String, Integer, DateTime, Boolean, Text, JSON, Float
from backend.database.database import Base

def generate_uuid():
    return str(uuid.uuid4())

class IOC(Base):
    __tablename__ = "iocs"
    id = Column(String, primary_key=True, default=generate_uuid)
    type = Column(String, index=True)
    value = Column(String, index=True, unique=True)
    confidence = Column(Integer, default=90)
    severity = Column(String, default="high")
    threat_type = Column(String, default="Malware C2")
    reputation_score = Column(Integer, default=85)
    status = Column(String, default="active")
    tags = Column(JSON, default=list)
    created_at = Column(DateTime, default=datetime.utcnow)

class ThreatActor(Base):
    __tablename__ = "threat_actors"
    id = Column(String, primary_key=True, default=generate_uuid)
    name = Column(String, index=True, unique=True)
    origin_country = Column(String)
    motive = Column(String)
    target_sectors = Column(JSON, default=list)
    aliases = Column(JSON, default=list)
    risk_level = Column(String, default="CRITICAL")

class Malware(Base):
    __tablename__ = "malware_catalog"
    id = Column(String, primary_key=True, default=generate_uuid)
    name = Column(String, index=True, unique=True)
    family = Column(String)
    type = Column(String)
    yara_rule = Column(Text)

class Campaign(Base):
    __tablename__ = "campaigns"
    id = Column(String, primary_key=True, default=generate_uuid)
    name = Column(String, index=True)
    actor_name = Column(String)
    status = Column(String, default="ACTIVE")
    kill_chain = Column(JSON, default=list)

class Alert(Base):
    __tablename__ = "alerts"
    id = Column(String, primary_key=True, default=generate_uuid)
    title = Column(String)
    severity = Column(String)
    source = Column(String)
    ioc_value = Column(String)
    mitre_tactic = Column(String)
    status = Column(String, default="NEW")
    created_at = Column(DateTime, default=datetime.utcnow)

class Incident(Base):
    __tablename__ = "incidents"
    id = Column(String, primary_key=True, default=generate_uuid)
    title = Column(String)
    severity = Column(String)
    status = Column(String, default="OPEN")
    assigned_analyst = Column(String)
    summary = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

class Asset(Base):
    __tablename__ = "assets"
    id = Column(String, primary_key=True, default=generate_uuid)
    name = Column(String, index=True)
    ip_address = Column(String)
    asset_type = Column(String)
    os_version = Column(String)
    criticality = Column(String, default="HIGH")
    status = Column(String, default="PROTECTED")

class Vulnerability(Base):
    __tablename__ = "vulnerabilities"
    id = Column(String, primary_key=True, default=generate_uuid)
    cve_id = Column(String, index=True, unique=True)
    cvss_score = Column(Float)
    cisa_kev = Column(Boolean, default=False)
    description = Column(Text)
    remediation_status = Column(String, default="OPEN")

class Report(Base):
    __tablename__ = "reports"
    id = Column(String, primary_key=True, default=generate_uuid)
    title = Column(String)
    report_type = Column(String)
    format = Column(String)
    status = Column(String, default="ready")
    created_at = Column(DateTime, default=datetime.utcnow)

class ThreatEvent(Base):
    __tablename__ = "threat_events"
    id = Column(String, primary_key=True, default=generate_uuid)
    location_name = Column(String)
    latitude = Column(Float)
    longitude = Column(Float)
    event_type = Column(String)
    intensity = Column(Integer, default=5)

# ═══════════════════════════════════════════════════════════
#  ENTERPRISE THREAT REPORTS — normalized schema (v2)
# ═══════════════════════════════════════════════════════════

class ThreatReport(Base):
    """Primary report record — normalized enterprise threat report."""
    __tablename__ = "threat_reports"
    id                  = Column(String,  primary_key=True, default=generate_uuid)
    report_id_display   = Column(String,  index=True, unique=True)   # e.g. RPT-2026-0042
    title               = Column(String,  index=True)
    category            = Column(String,  index=True, default="Incident")
    severity            = Column(String,  index=True, default="HIGH")
    status              = Column(String,  index=True, default="OPEN")
    threat_type         = Column(String,  default="APT")
    affected_assets     = Column(JSON,    default=list)               # list of asset names
    assigned_analyst    = Column(String,  default="Unassigned")
    classification      = Column(String,  default="TLP:RED")
    risk_score          = Column(Integer, default=75)
    confidence_level    = Column(Integer, default=85)
    version             = Column(Integer, default=1)
    # Long-form content
    executive_summary   = Column(Text,    default="")
    business_impact     = Column(Text,    default="")
    threat_overview     = Column(Text,    default="")
    overall_recommendation = Column(Text, default="")
    # Dates
    created_at          = Column(DateTime, default=datetime.utcnow)
    updated_at          = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    review_date         = Column(DateTime, nullable=True)
    closed_at           = Column(DateTime, nullable=True)
    deleted_at          = Column(DateTime, nullable=True)             # soft delete


class ReportVersion(Base):
    """Snapshot of a ThreatReport at a point in time."""
    __tablename__ = "report_versions"
    id              = Column(String,  primary_key=True, default=generate_uuid)
    report_id       = Column(String,  index=True)                     # FK → threat_reports.id
    version_number  = Column(Integer, default=1)
    change_summary  = Column(String,  default="Initial version")
    content_snapshot= Column(JSON,    default=dict)                   # full report JSON snapshot
    created_by      = Column(String,  default="system")
    created_at      = Column(DateTime, default=datetime.utcnow)


class ReportTag(Base):
    """Many-to-many tags for a ThreatReport."""
    __tablename__ = "report_tags"
    id          = Column(String, primary_key=True, default=generate_uuid)
    report_id   = Column(String, index=True)
    tag         = Column(String, index=True)
    created_at  = Column(DateTime, default=datetime.utcnow)


class ReportAttachment(Base):
    """Evidence files attached to a ThreatReport."""
    __tablename__ = "report_attachments"
    id            = Column(String,  primary_key=True, default=generate_uuid)
    report_id     = Column(String,  index=True)
    filename      = Column(String)
    file_type     = Column(String)
    size_bytes    = Column(Integer, default=0)
    url           = Column(String,  default="")
    uploaded_by   = Column(String,  default="analyst")
    created_at    = Column(DateTime, default=datetime.utcnow)


class ReportIOC(Base):
    """IOC indicator linked to a ThreatReport."""
    __tablename__ = "report_iocs"
    id          = Column(String,  primary_key=True, default=generate_uuid)
    report_id   = Column(String,  index=True)
    ioc_type    = Column(String,  index=True)                         # IP/DOMAIN/HASH/URL/EMAIL/FILE/CERT
    value       = Column(String)
    confidence  = Column(Integer, default=85)
    status      = Column(String,  default="ACTIVE")
    first_seen  = Column(DateTime, nullable=True)
    last_seen   = Column(DateTime, nullable=True)
    created_at  = Column(DateTime, default=datetime.utcnow)


class ReportTimelineEvent(Base):
    """Incident timeline event for a ThreatReport."""
    __tablename__ = "report_timeline_events"
    id          = Column(String,  primary_key=True, default=generate_uuid)
    report_id   = Column(String,  index=True)
    phase       = Column(String)                                       # Detection/Analysis/Escalation/…
    event_ts    = Column(DateTime, default=datetime.utcnow)
    analyst     = Column(String,  default="SOC Analyst")
    description = Column(Text,   default="")
    status      = Column(String,  default="COMPLETED")
    created_at  = Column(DateTime, default=datetime.utcnow)


class ReportMitigation(Base):
    """Recommended and completed mitigation actions for a ThreatReport."""
    __tablename__ = "report_mitigations"
    id                   = Column(String,  primary_key=True, default=generate_uuid)
    report_id            = Column(String,  index=True)
    action               = Column(Text)
    priority             = Column(String,  default="HIGH")
    status               = Column(String,  default="PENDING")         # PENDING/IN_PROGRESS/COMPLETED
    verified_by          = Column(String,  nullable=True)
    estimated_completion = Column(DateTime, nullable=True)
    completed_at         = Column(DateTime, nullable=True)
    created_at           = Column(DateTime, default=datetime.utcnow)


class ReportAuditLog(Base):
    """Full audit trail for all changes to a ThreatReport."""
    __tablename__ = "report_audit_logs"
    id          = Column(String,  primary_key=True, default=generate_uuid)
    report_id   = Column(String,  index=True)
    action      = Column(String)                                       # CREATED/UPDATED/DELETED/EXPORTED/…
    actor       = Column(String,  default="system")
    field       = Column(String,  nullable=True)
    old_value   = Column(Text,   nullable=True)
    new_value   = Column(Text,   nullable=True)
    created_at  = Column(DateTime, default=datetime.utcnow)


class ReportDownload(Base):
    """Track every export/download of a ThreatReport."""
    __tablename__ = "report_downloads"
    id              = Column(String,  primary_key=True, default=generate_uuid)
    report_id       = Column(String,  index=True)
    format          = Column(String)                                   # PDF/DOCX/XLSX/CSV
    downloaded_by   = Column(String,  default="analyst")
    created_at      = Column(DateTime, default=datetime.utcnow)
