import asyncio
from backend.database.database import AsyncSessionLocal, engine, Base
from backend.database.models import IOC, ThreatActor, Alert, Incident, Asset, Vulnerability, ThreatEvent

async def seed_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async with AsyncSessionLocal() as db:
        # Check existing
        existing_iocs = (await db.execute(IOC.__table__.select())).fetchall()
        if existing_iocs:
            return

        iocs = [
            # 5 IPs
            IOC(type="ip", value="185.220.101.45", confidence=95, severity="critical", threat_type="APT29 Cozy Bear Spear-Phishing C2", reputation_score=98, tags=["IP", "C2", "APT29"]),
            IOC(type="ip", value="103.21.58.10", confidence=98, severity="critical", threat_type="LockBit 3.0 Ransomware Infrastructure", reputation_score=99, tags=["IP", "LockBit", "Ransomware"]),
            IOC(type="ip", value="194.26.29.112", confidence=88, severity="high", threat_type="Botnet Cluster B4 SSH Intrusion Relay", reputation_score=85, tags=["IP", "Botnet", "BruteForce"]),
            IOC(type="ip", value="91.240.118.172", confidence=92, severity="critical", threat_type="APT33 Exploitation & Exploit Relay", reputation_score=94, tags=["IP", "APT33", "RCE"]),
            IOC(type="ip", value="45.33.32.156", confidence=85, severity="high", threat_type="DNS Tunnel Data Exfiltration Node", reputation_score=82, tags=["IP", "DNS-Tunnel", "Exfil"]),

            # 5 Domains
            IOC(type="domain", value="auth-verify-security-login.com", confidence=96, severity="critical", threat_type="Credential Harvesting Phishing Domain", reputation_score=97, tags=["Domain", "Phishing", "OAuth"]),
            IOC(type="domain", value="update-service-cdn-cloud.net", confidence=90, severity="high", threat_type="Cobalt Strike DNS Beaconing Domain", reputation_score=89, tags=["Domain", "CobaltStrike", "C2"]),
            IOC(type="domain", value="microsoft-online-sso-portal.info", confidence=94, severity="critical", threat_type="Spear-Phishing Landing Domain", reputation_score=96, tags=["Domain", "Typosquat", "Phishing"]),
            IOC(type="domain", value="darknet-c2-panel.xyz", confidence=95, severity="critical", threat_type="Qakbot Command & Control Domain", reputation_score=98, tags=["Domain", "Qakbot", "Botnet"]),
            IOC(type="domain", value="fast-dl-payload-srv.org", confidence=78, severity="medium", threat_type="Malware Staging & Dropper Host", reputation_score=75, tags=["Domain", "Dropper", "Staging"]),

            # 5 URLs
            IOC(type="url", value="http://185.220.101.45/payload/stage2.bin", confidence=97, severity="critical", threat_type="DLL Side-Loading Malicious Binary", reputation_score=99, tags=["URL", "DLL-SideLoading", "Payload"]),
            IOC(type="url", value="https://update-service-cdn-cloud.net/api/v1/beacon", confidence=91, severity="high", threat_type="Cobalt Strike Malleable C2 Endpoint", reputation_score=90, tags=["URL", "CobaltStrike", "Beacon"]),
            IOC(type="url", value="http://auth-verify-security-login.com/login/phish.php", confidence=95, severity="critical", threat_type="OAuth Token Theft Phishing Endpoint", reputation_score=96, tags=["URL", "Phishing", "CredentialTheft"]),
            IOC(type="url", value="https://darknet-c2-panel.xyz/gate.php?id=bot99", confidence=89, severity="high", threat_type="TrickBot Bot Registration Gate", reputation_score=88, tags=["URL", "Trickbot", "BotnetGate"]),
            IOC(type="url", value="http://91.240.118.172/downloads/lockbit3_encryptor.exe", confidence=99, severity="critical", threat_type="LockBit Ransomware Direct Executable", reputation_score=100, tags=["URL", "LockBit", "Executable"]),

            # 5 Hashes
            IOC(type="hash", value="e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855", confidence=99, severity="critical", threat_type="LockBit 3.0 Encryptor SHA256", reputation_score=100, tags=["SHA256", "LockBit", "Ransomware"]),
            IOC(type="hash", value="4f8a9b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a", confidence=96, severity="critical", threat_type="Cobalt Strike Stager DLL SHA256", reputation_score=97, tags=["SHA256", "CobaltStrike", "DLL"]),
            IOC(type="hash", value="a1b2c3d4e5f67890123456789abcdef0123456789abcdef0123456789abcdef0", confidence=90, severity="high", threat_type="QakBot Loader Payload SHA256", reputation_score=91, tags=["SHA256", "Qakbot", "Loader"]),
            IOC(type="hash", value="7c9e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e", confidence=87, severity="high", threat_type="Emotet Banking Trojan Artifact", reputation_score=86, tags=["SHA256", "Emotet", "Trojan"]),
            IOC(type="hash", value="f0e9d8c7b6a543210fedcba9876543210fedcba9876543210fedcba987654321", confidence=94, severity="critical", threat_type="ShadowPad Remote Access Trojan SHA256", reputation_score=95, tags=["SHA256", "ShadowPad", "RAT"])
        ]
        db.add_all(iocs)

        actors = [
            ThreatActor(name="APT29 (Cozy Bear)", origin_country="Russia", motive="Espionage", target_sectors=["Defense", "Government", "Energy"], aliases=["NOBELIUM"]),
            ThreatActor(name="APT41 (Double Dragon)", origin_country="China", motive="Financial & Espionage", target_sectors=["Healthcare", "Telecom"], aliases=["Wicked Panda"]),
            ThreatActor(name="Lazarus Group", origin_country="North Korea", motive="Crypto & Financial", target_sectors=["Fintech", "Defense"], aliases=["HIDDEN COBRA"])
        ]
        db.add_all(actors)

        alerts = [
            Alert(id="ALT-101", title="Port 443 Beaconing to C2 IP 103.21.58.10", severity="CRITICAL", source="FIREWALL_SYS", ioc_value="103.21.58.10", mitre_tactic="TA0011"),
            Alert(id="ALT-102", title="DNS Tunneling to malicious-exfil-node.net", severity="HIGH", source="DNS_PROXY", ioc_value="malicious-exfil-node.net", mitre_tactic="TA0011")
        ]
        db.add_all(alerts)

        incidents = [
            Incident(id="INC-2026-001", title="Active LockBit Ransomware Beaconing", severity="CRITICAL", status="OPEN", assigned_analyst="Tier 3 SOC Lead", summary="C2 beaconing detected from DC01.threatnexus.local to 103.21.58.10.")
        ]
        db.add_all(incidents)

        assets = [
            Asset(name="DC01.threatnexus.local", ip_address="10.0.1.5", asset_type="Domain Controller", os_version="Windows Server 2022", criticality="MISSION_CRITICAL", status="PROTECTED"),
            Asset(name="DB-PRIMARY-01", ip_address="10.0.2.10", asset_type="Database Server", os_version="Ubuntu 22.04 LTS", criticality="HIGH", status="PROTECTED")
        ]
        db.add_all(assets)

        vulns = [
            Vulnerability(cve_id="CVE-2024-3094", cvss_score=10.0, cisa_kev=True, description="XZ Utils backdoor allowing remote code execution."),
            Vulnerability(cve_id="CVE-2023-4863", cvss_score=8.8, cisa_kev=True, description="Heap buffer overflow in libwebp engine.")
        ]
        db.add_all(vulns)

        events = [
            ThreatEvent(location_name="Mumbai, IN", latitude=19.0760, longitude=72.8777, event_type="C2 Beaconing", intensity=9),
            ThreatEvent(location_name="Delhi, IN", latitude=28.6139, longitude=77.2090, event_type="LockBit Ransomware", intensity=8)
        ]
        db.add_all(events)

        await db.commit()

if __name__ == "__main__":
    asyncio.run(seed_db())
