from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.core.config import settings
from backend.database.seed import seed_db
from backend.api.router import api_router
from backend.websocket.ws_engine import router as ws_router

@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        await seed_db()
    except Exception as e:
        print(f"Database startup seeding note: {e}")
    yield

app = FastAPI(
    title=settings.PROJECT_NAME,
    openapi_url=f"{settings.API_V1_STR}/openapi.json",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.BACKEND_CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix=settings.API_V1_STR)
app.include_router(ws_router, prefix=f"{settings.API_V1_STR}/ws")

@app.get("/")
async def root():
    return {
        "message": "Welcome to ShadowNexus CTI & Omega Prime SOC OS Platform API",
        "docs": "/docs",
        "cti_connector": "/api/v1/cti/status"
    }
