import os
from pydantic_settings import BaseSettings
from typing import List, Optional

class Settings(BaseSettings):
    PROJECT_NAME: str = "ShadowNexus CTI Luxury OS"
    API_V1_STR: str = "/api/v1"
    SECRET_KEY: str = os.getenv("SECRET_KEY", "shadownexus-super-secret-key-32-chars-long!")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 # 24 hours
    ALGORITHM: str = "HS256"

    # Database
    SQLITE_DB_PATH: str = os.getenv("SQLITE_DB_PATH", "backend/shadownexus.db")

    # CTI Platform GraphQL Backend (https://github.com/OpenCTI-Platform/opencti.git)
    CTI_URL: str = os.getenv("CTI_URL", os.getenv("OPENCTI_URL", "http://localhost:8080"))
    CTI_TOKEN: str = os.getenv("CTI_TOKEN", os.getenv("OPENCTI_TOKEN", "cti-api-token-secret-key"))

    # Threat Intel API Keys
    VIRUSTOTAL_API_KEY: Optional[str] = os.getenv("VIRUSTOTAL_API_KEY", "")
    ABUSEIPDB_API_KEY: Optional[str] = os.getenv("ABUSEIPDB_API_KEY", "")
    SHODAN_API_KEY: Optional[str] = os.getenv("SHODAN_API_KEY", "")
    OTX_API_KEY: Optional[str] = os.getenv("OTX_API_KEY", "")
    GEMINI_API_KEY: Optional[str] = os.getenv("GEMINI_API_KEY", "")

    BACKEND_CORS_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:5173",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:5173",
    ]

    class Config:
        case_sensitive = True

settings = Settings()
