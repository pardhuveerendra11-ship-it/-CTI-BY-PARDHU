import pytest
from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)

def test_root_endpoint():
    res = client.get("/")
    assert res.status_code == 200
    assert "message" in res.json()

def test_cti_status_endpoint():
    res = client.get("/api/v1/cti/status")
    assert res.status_code == 200
    data = res.json()
    assert "cti_platform" in data
    assert "repository_url" in data

def test_cti_indicators_endpoint():
    res = client.get("/api/v1/cti/indicators")
    assert res.status_code == 200
    data = res.json()
    assert "indicators" in data

def test_dashboard_summary():
    res = client.get("/api/v1/dashboard/summary")
    assert res.status_code == 200
    assert "active_iocs" in res.json()

def test_omega_prime_summary():
    res = client.get("/api/v1/omega-prime/summary")
    assert res.status_code == 200
    assert "security_score" in res.json()

def test_omega_intel_dashboard():
    res = client.get("/api/v1/omega/intel/dashboard")
    assert res.status_code == 200
    assert "kpis" in res.json()

def test_monitoring_alerts():
    res = client.get("/api/v1/monitoring/alerts")
    assert res.status_code == 200

def test_incidents_list():
    res = client.get("/api/v1/incidents")
    assert res.status_code == 200

def test_assets_list():
    res = client.get("/api/v1/assets")
    assert res.status_code == 200

def test_vulnerabilities_list():
    res = client.get("/api/v1/vulnerabilities")
    assert res.status_code == 200

def test_analytics_trends():
    res = client.get("/api/v1/analytics/trends")
    assert res.status_code == 200

def test_reports_preview():
    res = client.get("/api/v1/reports/preview")
    assert res.status_code == 200
    assert "data" in res.json()
