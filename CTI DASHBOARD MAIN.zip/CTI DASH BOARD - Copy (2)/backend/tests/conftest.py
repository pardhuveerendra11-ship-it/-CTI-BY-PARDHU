import asyncio
import pytest
from backend.database.database import engine, Base
from backend.database.seed import seed_db

@pytest.fixture(scope="session", autouse=True)
def initialize_db():
    """Create all tables and seed data before the test session starts."""
    asyncio.get_event_loop().run_until_complete(seed_db())
    yield
